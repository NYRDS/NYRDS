--
-- User: mike
-- Date: 29.01.2019
-- Time: 20:33
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/revampedCommonClasses"

local item = require "scripts/lib/item"

local quest = require "scripts/lib/quest"

local storage = require "scripts/lib/storage"

local mob
local DeathCounter = "DeathCounter"
local Mobs = {"Rat","Gnoll","Albino","Mimic","MimicPie","MimicAmulet","TombRaider","SandWorm","TombWorm","BoneDragon","Goo","Tengu","CactusMimic","Wraith","MoneyGiver","Shopkeeper","CockerSpaniel","CockerSpanielNPC","BlackCat","BlackCatNPC"}

return item.init{
    desc  = function (self, item)

        return {
            image         = 5,
            imageFile     = "items/rings.png",
            name          = "Testing Item",
            info          = "Item for tests and target dummies.",
            stackable     = false,
            upgradable    = false,
            identified    = true,
            defaultAction = "Get Level Data",
            price         = 0
        }
    end,
    actions = function(self, item, hero)
        return {"Get Level Data","Get Mob Data","Summon Money Giver","Summon Target","Summon Shopkeeper","Hurt Everything","Tp to Yog","Tp to Bone Dragon","Death Counter"}
    end,

    execute = function(self, item, hero, action)
        local hero = RPD.Dungeon.hero
        local levelId = RPD.Dungeon.levelId
        local level = RPD.Dungeon.level
        local cellPos = RPD.getXy(hero)

        if action == "Get Level Data" then
            RPD.glog("Level: "..tostring(level)..",\nLevel ID: "..tostring(levelId)..",\nCell X: "..cellPos[1]..",\nCell Y: "..cellPos[2]..",\nMax Width: "..level:getWidth()..",\nMax Height: "..level:getHeight())
        end

        if action == "Get Mob Data" then
            local level = RPD.Dungeon.level
            local target
            for x = 0, level:getWidth() do
                for y = 0, level:getHeight() do
                    target = RPD.Actor:findChar(level:cell(x,y))
                    if target then
                        if target ~= item:getUser() then
                            RPD.glog("Mob: "..target:name()..",\nMob Id: "..tostring(target:getId())..",\nMob Class: "..target:getMobClassName()..",\nAi State: "..tostring(target:getState())..",\nHt: "..tostring(target:ht()).."\nHp: "..tostring(target:hp())..",\nPos X: "..tostring(level:cellX(target:getPos()))..",\nPos Y: "..tostring(level:cellY(target:getPos()))..",\nOwner Id: "..tostring(target:getOwnerId()))
                        else
                            RPD.glog("Mob: "..target:name()..",\nClass Name: "..target:className()..",\nLevel: "..target:lvl()..",\nHt: "..tostring(target:ht()).."\nHp: "..tostring(target:hp())..",\nMt: "..tostring(target:getSkillPointsMax())..",\nMp: "..tostring(target:getSkillPoints())..",\nStr: "..tostring(target:STR())..",\nDr: "..tostring(target:dr())..",\nPos X: "..tostring(level:cellX(target:getPos()))..",\nPos Y: "..tostring(level:cellY(target:getPos())))
                        end
                    end
                end
            end
        end

        if action == "Summon Money Giver" then
            local cell = level:getEmptyCellNextTo(hero:getPos())
            if level:cellValid(cell) then
                mob = RPD.MobFactory:mobByName("TempMoney")
                mob:setPos(cell)
                RPD.setAi(mob, "Wandering")
                level:spawnMob(mob)
                RPD.glogp("Summoned Money Giver.")
                return true
            end
            RPD.glogn("There's not enough space for the summon.")
            return false
        end

        if action == "Summon Target" then
            local cell = level:getEmptyCellNextTo(hero:getPos())
            if level:cellValid(cell) then
                mob = RPD.MobFactory:mobByName("Rat")
                mob:setPos(cell)
                mob:ht(2^31-1)
                mob:hp(mob:ht())
                RPD.permanentBuff(mob, RPD.Buffs.Roots)
                RPD.setAi(mob, "Wandering")
                level:spawnMob(mob)
                RPD.glogp("Summoned Target.")
                return true
            end
            RPD.glogn("There's not enough space for the summon.")
            return false
        end

        if action == "Summon Shopkeeper" then
            local cell = level:getEmptyCellNextTo(hero:getPos())
            if level:cellValid(cell) then
                mob = RPD.MobFactory:mobByName("Shopkeeper")
                mob:setPos(cell)
                RPD.setAi(mob, "Wandering")
                level:spawnMob(mob)
                RPD.glogp("Summoned Shopkeeper.")
                return true
            end
            RPD.glogn("There's not enough space for the summon.")
            return false
        end

        if action == "Hurt Everything" then
            for x = 0, level:getWidth() do
                for y = 0, level:getHeight() do
                    local target = RPD.Actor:findChar(level:cell(x,y))
                    if target then
                        if target ~= item:getUser() and not target:isPet() then
                            target:damage(target:hp()-1, item:getUser())
                        end
                    end
                end
            end
        end

        if action == "Tp to Bone Dragon" then
            local portal = {kind="PortalGateSender",target={levelId="tombFinal",x=7,y=11}}
            RPD.createLevelObject(portal, hero:getPos())
        end

        if action == "Tp to Yog" then
            local portal = {kind="PortalGateSender",target={levelId="31",x=16,y=16}}
            RPD.createLevelObject(portal, hero:getPos())
        end

        if action == "Death Counter" then
            for i = 1, #Mobs do
                if storage.get(Mobs[i].." kills") then
                    RPD.glog(Mobs[i].." kills: "..tostring(storage.get(Mobs[i].." kills")))
                else
                    RPD.glog(Mobs[i].." kills: 0")
                end
            end
        end
    end,

    bag = function(self, item)
        return "Keyring"
    end
}
