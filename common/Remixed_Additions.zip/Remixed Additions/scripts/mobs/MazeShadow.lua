--
-- User: mike
-- Date: 23.11.2017
-- Time: 21:04
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"
local mob = require"scripts/lib/mob"

local wallTiles = {0=false,4=false,10=false,12=false,13=false,16=false,25=false,26=false,35=false,36=false,41=false,43=false,44=false,45=false,46=false}

return mob.init({
    interact = function(self, chr)
        local ownPos = self:getPos()
        local newPos = chr:getPos()
        local level = ROD.Dungeon.level
        if wallTiles[level.map[own]] then
            self:move(newPos)
            self:getSprite():move(ownPos, newPos)
            chr:move(ownPos)
            chr:getSprite():move(newPos, ownPos)
        end
    end
})