--
-- User: mike
-- Date: 25.11.2017
-- Time: 23:57
-- This file is part of Remixed Pixel Dungeon.
--

local mob = require"scripts/lib/mob"

return mob.init({})



