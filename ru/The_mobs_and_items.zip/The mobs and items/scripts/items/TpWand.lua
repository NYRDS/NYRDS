--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
            image         = 0,
            imageFile     = "items/wands_remastered.png",
            name          = "Жезл телепортации",
            info          = "Этот жезл состоит из металла с вырезанными на нём рунами. При использовании он телепортирует героя на любую клетку этого уровня.",
            stackable     = false,
            defaultAction = "Wand_ACZap",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action, cause )
        if action == RPD.Actions.zap then
        local level = RPD.Dungeon.level

      local hero = RPD.Dungeon.hero
        local levelSize = level:getLength()
        local cell = math.random(levelSize)-1
        if not RPD.Dungeon.level.solid[cell] then
local ownPos = hero:getPos()
       hero:move(cell)
      hero:getSprite():move(ownPos, cell)  
hero:setSoulPoints(-20)
end
end
end
}