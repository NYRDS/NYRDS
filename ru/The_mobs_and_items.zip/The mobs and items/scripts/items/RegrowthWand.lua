--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 3,
            imageFile = "items/wands_remastered.png",
            name      = "Жезл возраждения",
            info      = "Жезл состоит из какого-то магического дерева. При использовании вызывает цветение растений рядом с героем.",
            stackable = false,
            upgradable    = false,
 
             price     = 45
        }
    end, actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action, cell)
        if action == RPD.Actions.zap then        local level = RPD.Dungeon.level
        local hero = RPD.Dungeon.hero
        print(self, cause)

        for i = 1,2 do
              local pos = level:getEmptyCellNextTo(hero:getPos())
            if (level:cellValid(pos)) then      RPD.placeBlob( RPD.Blobs.Regrowth , pos, 50 );
hero:setSoulPoints(-20)
         end
    end
  end
 end 

        
}
    

