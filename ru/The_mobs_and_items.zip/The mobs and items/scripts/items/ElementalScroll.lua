--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = math.random(0,11),
            imageFile = "items/Scrolls.png",
            name          = "Свиток стихий",
            info          = "При использовании этот свиток создаст случайного элементаля рядом с героем.",
            stackable     = true,
            defaultAction = "Scroll_ACRead",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.read} end,
    execute = function(self, item, hero, action, cause )
        if action == RPD.Actions.read then
local mobs = {
 "AirElemental",
"WaterElemental",
"EarthElemental",
"Elemental",
"IceElemental",
"LightingElemental"
}


        local level = RPD.Dungeon.level

        local hero = RPD.Dungeon.hero
            local mob = RPD.MobFactory:mobByName(mobs[math.random(1,6)])
            local pos = level:getEmptyCellNextTo(hero:getPos())
            if (level:cellValid(pos)) then
                mob:setPos(pos)
level:spawnMob(RPD.Mob:makePet(mob,RPD.Dungeon.hero));
 hero:eat(item,0,"Сущность создана")
                
    end
  end
 end 

}