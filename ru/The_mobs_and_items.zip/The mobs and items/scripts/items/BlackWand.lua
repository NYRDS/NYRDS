--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local hero = RPD.Dungeon.hero

local item = require "scripts/lib/item"

 local mob = require "scripts/lib/mob"

local storage = require "scripts/lib/storage"

local latest_kill_index = "__latest_dead_mob"

local function updateLatestDeadMob(mob)
    storage.put(latest_kill_index, {class = mob:getMobClassName(), pos = mob:getPos()})
end

mob.installOnDieCallback(updateLatestDeadMob)



return item.init{
    desc  = function ()
        return {
            image         = 6,
            imageFile     = "items/wands_remastered.png",
            name          = "Жезл тьмы",
            info          = "Этот жезл состоит из древнего очень прочного материала, обсидиана. На стержне  заметны древние руны. Верхняя часть состоит из тёмного кристалла. При использовании воскрешает последнего убитого монстра на уровне за 20 маны.",
            stackable     = false,
            defaultAction = "Wand_ACZap",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then
        local latestDeadMob = storage.get(latest_kill_index) or {}

        if latestDeadMob.class ~= nil then
            local mob = RPD.MobFactory:mobByName(latestDeadMob.class)
            storage.put(latest_kill_index, {})
           
            local level = RPD.Dungeon.level
            local mobPos = latestDeadMob.pos

            if level:cellValid(mobPos) then
                mob:setPos(mobPos)
                mob:loot(RPD.ItemFactory:itemByName("Gold"))
                RPD.Mob:makePet(mob, hero)
                level:spawnMob(mob)
 hero:setSoulPoints(-20)
                hero:getSprite():emitter():burst( RPD.Sfx.ShadowParticle.CURSE, 6 )
                mob:getSprite():emitter():burst( RPD.Sfx.ShadowParticle.CURSE, 6 )
                RPD.playSound( "snd_cursed.mp3" )

                return true
            else
                RPD.glog("RaiseDead_NoSpace")
                return false
            end
        end

        RPD.glog("RaiseDead_NoKill")
        return false
    end
  end
}