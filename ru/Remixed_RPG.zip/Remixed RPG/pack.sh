#!/bin/bash

git archive -o Remixed_RPG.zip --prefix='Remixed RPG/' HEAD
cp -f Remixed_RPG.zip ../NYRDS/ru

