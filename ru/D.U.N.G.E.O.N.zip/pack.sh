#!/bin/bash

git archive -o D.U.N.G.E.O.N.zip HEAD
cp -f D.U.N.G.E.O.N.zip ../NYRDS/ru

