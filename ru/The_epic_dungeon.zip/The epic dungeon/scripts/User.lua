local User ={
host = "Host", -- здесь нужно указать ник хоста 
player = "Player", -- здесь нужно указать ник игрока
status = "Host/Player" -- здесь нужно указать ник того, кем вы являетесь в этом подключении host или player
}
return User