--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
            image         = 22,
            imageFile     = "items/materials.png",
            name          = "Свиток полной луны",
            info          = "Этот могущественный свиток наложит на уровень заклятье, которое значительно поможет герою.",
            stackable     = false,
            defaultAction = "Scrolls_ACRead",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.read} end,
    execute = function(self, item, hero, action, cause )
        if action == RPD.Actions.read then
RPD.Dungeon.hero:eat(item,0 ,"desc");
        RPD.Dungeon.level:addScriptedActor(RPD.new(RPD.Objects.Actors.ScriptedActor,"scripts/actors/Buffs/MagicAura"))
    end
         end 

}