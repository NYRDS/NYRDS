--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = math.random(0,11),
            imageFile = "items/Scrolls.png",
            name          = "Свиток времени",
            info          = "При прочтении этот свиток телепортирует героя в будущее",
            stackable     = true,
            defaultAction = "Scroll_ACRead",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.read} end,
    execute = function(self, item, hero, action)
        if action == RPD.Actions.read then
            RPD.Buffs.Buff:affect(hero, RPD.Buffs.Invisibility ,70);           RPD.Buffs.Buff:affect(hero, RPD.Buffs.Paralysis ,70)
            hero:eat(item,0,"Команда исполнена")
        end
    end
}
