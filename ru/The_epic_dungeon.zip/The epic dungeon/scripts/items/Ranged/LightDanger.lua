--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 5,
            imageFile = "items/Ranged.png",
            name      = "Кинжал света",
            info      = "Лезвие этого кинжала сделано из хрусталя, на рукояди из железа есть еле заметные узоры. Интересно, зачем он нужен?",
            stackable = true,
            price     = 10
        }
    end,
    onThrow = function(self, item, cell )
                local soul =  RPD.Actor:findChar(cell)
                if soul then
RPD.playSound( "dash.mp3")
RPD.affectBuff(soul, RPD.Buffs.Vertigo , 5+item:level());
RPD.affectBuff(soul, RPD.Buffs.Light , 5+item:level());
soul:getSprite():emitter():burst( RPD.Sfx.ShadowParticle.UP, 8 )
    else
item:dropTo(cell)
end
end
}