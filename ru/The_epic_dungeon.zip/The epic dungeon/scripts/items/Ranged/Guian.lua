--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

return item.init{
    desc  = function ()
        return {
           image     = 2,
            imageFile = "items/Ranged.png",
            name      = "Гаян",
            info      = "Этот волшебный кинжал пропитан магией природы.",
            stackable = true,
            upgradable    = true,
            price     = 10
        }
    end,
    onThrow = function(self, item, cell,enemy,soul)
local soul =  RPD.Actor:findChar(cell)
                if soul then
        RPD.affectBuff(soul, RPD.Buffs.Roots , 10)
        soul:damage(20*(item:level()+1),RPD.Dungeon.hero)
RPD.playSound( "snd_hit.mp3")
        return dmg
    else
           item:dropTo(cell)
end
    end 
}