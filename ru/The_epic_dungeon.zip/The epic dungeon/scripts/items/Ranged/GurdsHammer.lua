--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 0,
            imageFile = "items/RangedMod.png",
            name      = "Молот",
            info      = "Этот огромный молот способен парализовать своим ударом любого врага.",
            stackable = true,
            upgradable    = true,
            price     = 100
        }
    end,
    onThrow = function(self, item, cell,enemy,soul)
local soul =  RPD.Actor:findChar(cell)
                if soul then
        RPD.affectBuff(soul, RPD.Buffs.Paralysis , 5+item:level())
        soul:damage(math.random(4,5)*(item:level()+1),RPD.Dungeon.hero)
RPD.playSound( "snd_hit.mp3")
        return dmg
    else
           item:dropTo(cell)
end
    end 
}