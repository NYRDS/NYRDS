--
-- User: mike
-- Date: 29.01.2019
-- Time: 20:33
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local shields = require "scripts/lib/shields"

local shieldLevel = 1
local shieldDesc  = "WoodenShield_desc"

local baseDesc = shields.makeShield(shieldLevel,shieldDesc)

baseDesc.desc = function (self, item)
    return {
        image         = 0,
        imageFile     = "items/shields.png",
        name          = "WoodenShield_name",
        info          = shieldDesc,
        price         = 20 * shieldLevel,
        equipable     = "left_hand",
        upgradable    = true
    }
end

        activate = function(self, item, hero)

            local shieldBuff = RPD.affectBuff(hero,"ShieldLeft", shields.rechargeTime(shieldLevel,hero:effectiveSTR()))
            shieldBuff:level(shieldLevel)
            shieldBuff:setSource(item)
        end,

        deactivate = function(self, item, hero)
            RPD.removeBuff(hero,"ShieldLeft")
        end,

        info = function(self, item)
            local hero = RPD.Dungeon.hero --TODO fix me
            local str = hero:effectiveSTR()

            return shields.info(shieldDesc, str, shieldLevel ,item:level())
        end
