--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 12,
            imageFile = "items/materials.png",
            name      = "Жезл эфрита",
            info      = "Подобные жезлы вращаются вокруг ядра у эфритов.",
            stackable = false,
            upgradable    = false,
             price     = 50
        }
    end, 
actions = function() return
{RPD.Actions.zap} end,

    cellSelected = function(self, thisItem, action, cell)
        if action == RPD.Actions.zap then
RPD.placeBlob( RPD.Blobs.Fire, cell, 10)
RPD.zapEffect(thisItem:getUser():getPos(),cell,"Fire")
        end
    end,

    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then
            item:selectCell(RPD.Actions.zap,"Выбирите клетку")
        end
    end,
}