--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 3,
            imageFile = "items/materials.png",
            name      = "Бомба",
            info      = "Эта бомба доверху набита порохом. Взрыв будет знатный.",
            stackable = true,
            upgradable    = false,
 
             price     = 45
        }
    end,
    onThrow = function(self, item, cell)
        local level = RPD.Dungeon.level
        local hero = RPD.Dungeon.hero
        if level.map[cell] then
        RPD.placeBlob( RPD.Blobs.LiquidFlame , cell, 50 );

        end
    end
}
