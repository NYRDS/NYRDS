--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local hero = RPD.Dungeon.hero

return item.init{
    desc  = function ()
        return {
            image         = 5,
            imageFile     = "items/wands_remastered.png",
            name          = "Жезл света",
            info          = "Этот жезл выглядит довольно красиво: он светится ярко-жёлтым светом, на его вершине находится хрусталь.",
            stackable     = false,
            defaultAction = "Wand_ACZap",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then

if hero:getSoulPoints() < 5 then
RPD.glogn("Не хватает маны")
return false
end
if hero:getSoulPoints() >= 5 then
   RPD.affectBuff(hero, RPD.Buffs.Light , 50*hero:magicLvl())
  hero:setSoulPoints(math.min( hero:getSoulPoints()-5,5))

return true
end 
end
end
}