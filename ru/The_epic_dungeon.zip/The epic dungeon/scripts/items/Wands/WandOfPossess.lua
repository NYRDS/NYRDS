--
-- User: mike
-- Date: 29.01.2019
-- Time: 20:33
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

return item.init{
    desc  = function ()
        return {
           image     = 8,
            imageFile = "items/Wands.png",
            name      = "Жезл одержимости",
            info      = "Имба",
            stackable = false,
            upgradable    = false,
             price     = 50
     
        }
    end,
    actions = function() return {RPD.Actions.zap} end,

    cellSelected = function(self, thisItem, action, cell)
        if action == RPD.Actions.zap then 
                local soul =  RPD.Actor:findChar(cell)
if soul then
soul:setState(RPD.MobAi:getStateByTag("ControlledAi"))
RPD.Mob:makePet(soul, RPD.Dungeon.hero)
            RPD.Dungeon.hero:setControlTarget(soul)
soul:getSprite():emitter():burst( RPD.Sfx.ElmoParticle.FACTORY, 5)
   else
     RPD.Sfx.CellEmitter:get(cell):burst( RPD.Sfx.ElmoParticle.FACTORY, 5)
     end
end
end,
    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then
            item:selectCell( RPD.Actions.zap ,"Кого благословить?")
        end
end
}
