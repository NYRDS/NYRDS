--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

ttf = 1

return item.init{ 
    desc  = function()

        return {
           image     = 8,
            imageFile = "items/WandsMod.png",
            name      = "Жезл одержимости",
            info      = "Имба",
            stackable = false,
            upgradable    = false,
             price     = 50,
equipable     = "left_hand"

     
        }
    end, 
actions = function()

actionn = ("ВЗМАХНУТЬ("..EPD.h.."/"..ttf..")")

return {actionn} 
end,
    activate = function(self, item, hero)
                RPD.removeBuff(item:getUser(), "Posses")

        RPD.permanentBuff(item:getUser(), "Posses")

    end,

    deactivate = function(self, item, hero)
                RPD.removeBuff(item:getUser(), "Posses")
    end,

    cellSelected = function(self, thisItem, action, cell)
        if action == actionn and cell ~= nil then
thisItem:getUser():getSprite():zap(cell)

if EPD.h  ~= 0 and EPD.h  <= ttf then

EPD.h  = EPD.h  - 1
storage.put("yuy",EPD.h )

local dst = RPD.Ballistica:cast(thisItem:getUser():getPos(), cell, true, true, true)
local lvl = thisItem:level()

                local soul =  RPD.Actor:findChar(dst)
if soul and soul ~= RPD.Dungeon.hero  then
soul:setState(RPD.MobAi:getStateByTag("ControlledAi"))
RPD.Mob:makePet(soul, RPD.Dungeon.hero)
            RPD.Dungeon.hero:setControlTarget(soul)
soul:getSprite():emitter():burst( RPD.Sfx.ElmoParticle.FACTORY, 5)
RPD.playSound( "snd_teleport.mp3" )
   else
     RPD.Sfx.CellEmitter:get(dst):burst( RPD.Sfx.ElmoParticle.FACTORY, 5)
     end

else 
RPD.glog("** Твоя палочка издаёт потрескивание: наверное, в ней кончились заряды.")
end

end
end,

    execute = function(self, item, hero, action)
        if actionn == action then
            item:selectCell(action,"Выбирите клетку")
        end
    end,
    bag = function(self, item)
        return "WandHolster"
    end

}