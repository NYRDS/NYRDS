--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

l = 3

if not storage.get("jjj") then
storage.put("jjj",EPD.d )
else
EPD.d = storage.get("jjj")
end

return item.init{
    desc  = function()
    if not storage.get("Chars") then
storage.put("Chars",true)
        RPD.permanentBuff(RPD.Dungeon.hero, "Chars");
end

        return {
           image     = 2,
            imageFile = "items/WandsMod.png",
            name      = "Жезл друида",
            info      = "При использовании этот жезл создаст жизненную энергию, способную как и навредть, так и воскреить... траву...",
            stackable = false,
            upgradable    = true,
             price     = 50,
equipable     = "left_hand"

        }
    end, 
actions = function()


action = ("ВЗМАХНУТЬ("..EPD.d.."/"..l..")")

return {action} 
end,
    activate = function(self, item, hero)
                RPD.removeBuff(RPD.Dungeon.hero, "Earth")

        RPD.permanentBuff(RPD.Dungeon.hero, "Earth")

    end,

    deactivate = function(self, item, hero)
                RPD.removeBuff(RPD.Dungeon.hero, "Earth")
    end,



    cellSelected = function(self, thisItem, action, cell)
        if action == action and cell ~= nil then
thisItem:getUser():getSprite():zap(cell)

if EPD.d  ~= 0 and EPD.d  <= n then

EPD.d  = EPD.d  - 1
storage.put("jjj",EPD.d )

local dst = RPD.Ballistica:cast(thisItem:getUser():getPos(), cell, true, true, true)
local enemy = RPD.Actor:findChar(dst)
local lvl = thisItem:level()

local level = RPD.Dungeon.level
        local x = level:cellX(dst)
        local y = level:cellY(dst)
        for i = x - 1-l, x + 1+l do
            for j = y - 1-l, y + 1+l do
            local pos = level:cell(i,j)
 if not level.solid[pos] then
EPD.ZapWand("WandOfRegrowth",lvl,thisItem:getUser(),pos)
end

if math.random(1,40) == 1 and pos ~= nil then
EPD.SpawnMob("EarthElemental",pos,true,true)
end
end
end

else
RPD.glog("** Твоя палочка издаёт потрескивание: наверное, в ней кончились заряды.")
end

end
end,

    execute = function(self, item, hero, action)
        if action == action then
            item:selectCell(action,"Выбирите клетку")
        end
    end,
    bag = function(self, item)
        return "WandHolster"
    end

}