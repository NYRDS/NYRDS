--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 10,
            imageFile = "items/Wands.png",
            name          = "Жезл иллюзиониста",
            info          = "Этот жезл покрыт странными древними рунами. Интересно, что будет если им взмахнуть.",
            stackable     = true,
            defaultAction = "Wand_ACZap",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action, cause )
        if action == RPD.Actions.zap then
        local level = RPD.Dungeon.level
        local hero = RPD.Dungeon.hero
for i=1,2 do
            local mob = RPD.MobFactory:mobByName("Mirror")
            local pos = level:getEmptyCellNextTo(hero:getPos())
            if (level:cellValid(pos)) then
                mob:setPos(pos)
level:spawnMob(RPD.Mob:makePet(mob,RPD.Dungeon.hero));
            RPD.Buffs.Buff:affect(hero, RPD.Buffs.Invisibility ,7)
    end
  end
 end 
end

}