--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

bbb = 3


return item.init{ 
    desc  = function() 

        return {
           image     = 18,
            imageFile = "items/WandsMod.png",
            name          = "Жезл иллюзиониста",
            info          = "Этот жезл покрыт странными древними рунами. Интересно, что будет если им взмахнуть.",
            stackable     = false,
            defaultAction = "Wand_ACZap",
            price         = 50,
equipable     = "left_hand"

     }
    end, 
actions = function()

actionn = ("ВЗМАХНУТЬ("..EPD.k.."/"..bbb..")")

return {actionn} 
end, 
    activate = function(self, item, hero)
                RPD.removeBuff(item:getUser(), "Mirror")

        RPD.permanentBuff(item:getUser(), "Mirror")

    end,

    deactivate = function(self, item, hero)
                RPD.removeBuff(item:getUser(), "Mirror")
    end,

    execute = function(self, thisItem, action)
        if actionn == action then
thisItem:getUser():getSprite():zap()

if EPD.k  ~= 0 and EPD.k  <= bbb then

EPD.k  = EPD.k  - 1
storage.put("lc",EPD.k )


        local level = RPD.Dungeon.level

        local hero = RPD.Dungeon.hero
        print(self, cause)

            local mob = RPD.MobFactory:mobByName("Bee")
            local pos = level:getEmptyCellNextTo(hero:getPos())
            if (level:cellValid(pos)) then
--                mob:setPos(pos)
--level:spawnMob(RPD.Mob:makePet(mob,RPD.Dungeon.hero));
local image  = thisItem:getUser():makeClone();
RPD.Wands.wandOfBlink:appear( image, pos );
    end

else 
RPD.glog("** Твоя палочка издаёт потрескивание: наверное, в ней кончились заряды.")
end

end
end,

--[[    execute = function(self, item, hero, action)
        if action == action then
            item:selectCell(action,"Выбирите клетку")
        end
    end,
--]]
    bag = function(self, item)
        return "WandHolster"
    end

}