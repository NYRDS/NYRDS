--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 3,
            imageFile = "items/Wands.png",
            name      = "Жезл кристализации",
            info      = "При использовании этот жезл начнёт начнёт кристализировать окружающую среду.",
            stackable = false,
            upgradable    = false,
             price     = 50
        }
    end, 
actions = function() return
{RPD.Actions.zap} end,

    cellSelected = function(self, thisItem, action, cell)
        if action == RPD.Actions.zap then
 local enemy = RPD.Actor:findChar(cell)
  if enemy then
RPD.topEffect(cell,"smash_blast")
  enemy:damage(70, thisItem:getUser())
        else
RPD.topEffect(cell,"smash_blast")
end
end
    end,

    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then
            item:selectCell(RPD.Actions.zap,"Выбирите клетку")
        end
    end,
}