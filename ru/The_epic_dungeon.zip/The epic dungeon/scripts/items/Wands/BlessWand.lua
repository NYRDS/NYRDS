--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

hth = 3


return item.init{ 
    desc  = function()  
        return {
            image         = 21,
            imageFile     = "items/wands_remastered.png",
            name          = "Жезл света",
            info          = "Этот жезл выглядит довольно красиво: он светится ярко-жёлтым светом, на его вершине находится хрусталь. Подобный жезл ты видел у епископа.",
            stackable     = false,
            defaultAction = "Wand_ACZap",

equipable     = "left_hand",

            price         = 50,
            upgradable    = true        }
    end, 
actions = function()

actionn = ("ВЗМАХНУТЬ("..EPD.e.."/"..hth..")")

return {actionn} 
end,

    cellSelected = function(self, thisItem, action, cell)
        if actionn == action and cell ~= nil then
thisItem:getUser():getSprite():zap(cell)

if EPD.e  ~= 0 and EPD.e  <= hth then
if thisItem:isEquipped(RPD.Dungeon
.hero) then
local dst = RPD.Ballistica:cast(thisItem:getUser():getPos(), cell, true, true, true)
local level = RPD.Dungeon.level
        local x = level:cellX(dst)
        local y = level:cellY(dst)
        for i = x - 1, x + 1 do
     for j = y - 1, y + 1 do
            local pos = level:cell(i,j)
 local soul =  RPD.Actor:findChar(pos)
            if soul and soul ~= RPD.Dungeon.hero then 
 RPD.affectBuff(soul, RPD.Buffs.Blessed , 30*(thisItem:level()+1));
if not level.solid[pos] then
     RPD.Sfx.CellEmitter:get(pos):burst( RPD.Sfx.ShaftParticle.FACTORY, 5)
end
else
if not level.solid[pos] then
     RPD.Sfx.CellEmitter:get(pos):burst( RPD.Sfx.ShaftParticle.FACTORY, 5)
end
end
end
end

end


EPD.e  = EPD.e  - 1
storage.put("si",EPD.e )

local dst = RPD.Ballistica:cast(thisItem:getUser():getPos(), cell, true, true, true)
local lvl = thisItem:level()

                local soul =  RPD.Actor:findChar(dst)
                if soul then
        RPD.affectBuff(soul, RPD.Buffs.Blessed , 50*(lvl+1));
        soul:getSprite():emitter():burst( RPD.Sfx.ShaftParticle.FACTORY, 5)
   else
     RPD.Sfx.CellEmitter:get(dst):burst( RPD.Sfx.ShaftParticle.FACTORY, 5)
end

else 
RPD.glog("** Твоя палочка издаёт потрескивание: наверное, в ней кончились заряды.")
end

end
end,

    execute = function(self, item, hero, action)
        if actionn == action then
            item:selectCell(action,"Выбирите клетку")
        end
    end,
    bag = function(self, item)
        return "WandHolster"
    end

}