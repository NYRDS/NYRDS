--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

ddd = 4


return item.init{
    desc  = function()  

        return {
           image     = 4,
            imageFile = "items/WandsMod.png",
            name      = "Жезл огненных рун",
            info      = "При использовании этот жезл выпустит млщное огненное заклятье.",
            stackable = false,
            upgradable    = true,
             price     = 50,
equipable     = "left_hand"

        }
    end, 
actions = function()


actionn = ("ВЗМАХНУТЬ("..EPD.f.."/"..ddd..")")

return {actionn} 
end,
    activate = function(self, item, hero)
                RPD.removeBuff(item:getUser(), RPD.Buffs.Light)

        RPD.permanentBuff(item:getUser(), RPD.Buffs.Light)

                RPD.removeBuff(item:getUser(), "Fire")

        RPD.permanentBuff(item:getUser(), "Fire")

    end,

    deactivate = function(self, item, hero)
            RPD.removeBuff(item:getUser(), RPD.Buffs.Light)
                RPD.removeBuff(item:getUser(), "Fire")
    end,

    cellSelected = function(self, thisItem, action, cell)
        if actionn == action and cell ~= nil then
thisItem:getUser():getSprite():zap(cell)

if EPD.f  ~= 0 and EPD.f  <= ddd then

EPD.f  = EPD.f  - 1
storage.put("ks",EPD.f )

local dst = RPD.Ballistica:cast(thisItem:getUser():getPos(), cell, true, true, true)
local enemy = RPD.Actor:findChar(dst)
local lvl = thisItem:level()

RPD.placeBlob( RPD.Blobs.LiquidFlame, dst, 60*(lvl+1))
RPD.zapEffect(thisItem:getUser():getPos(),dst,"Fire")
else 
RPD.glog("** Твоя палочка издаёт потрескивание: наверное, в ней кончились заряды.")
end

end
end,

    execute = function(self, item, hero, action)
        if actionn == action then
            item:selectCell(action,"Выбирите клетку")
        end
    end,
    bag = function(self, item)
        return "WandHolster"
    end

}