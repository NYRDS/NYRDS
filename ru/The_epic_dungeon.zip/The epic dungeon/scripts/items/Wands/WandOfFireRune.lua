--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 4,
            imageFile = "items/Wands.png",
            name      = "Жезл огненных рун",
            info      = "При использовании этот жезл выпустит млщное огненное заклятье.",
            stackable = false,
            upgradable    = false,
             price     = 50
        }
    end, 
actions = function() return
{RPD.Actions.zap} end,

    cellSelected = function(self, thisItem, action, cell)
        if action == RPD.Actions.zap then
 local enemy = RPD.Actor:findChar(cell)
  if enemy then
        RPD.zapEffect( thisItem:getUser():getPos(), enemy:getPos(), "Fire")
RPD.placeBlob( RPD.Blobs.LiquidFlame ,cell, 50 );
RPD.topEffect(cell,"lava_fountain")
        else
        RPD.zapEffect( thisItem:getUser():getPos(), cell, "Fire")
RPD.placeBlob( RPD.Blobs.LiquidFlame ,cell, 50 )
RPD.topEffect(cell,"FireRune1")
end
end
    end,

    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then
            item:selectCell(RPD.Actions.zap,"Выбирите клетку")
        end
    end,
}