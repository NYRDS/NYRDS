--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

byt = 2


return item.init{
    desc  = function()
        return {
            image         = 16,
            imageFile     = "items/WandsMod.png",
            name          = "Жезл некромантии",
            info          = "В этом маленьком на вид жезле находится могущественное заклятье некромантии. Оно очень быстро растворяется в воздухе, но если его подхватить, то жертва будет умирать очень долго и мучительно.",
            stackable     = false,
            defaultAction = "Wand_ACZap",
equipable     = "left_hand",

            price         = 50,
            upgradable    = true
        }
    end, 
actions = function()

actionn = ("ВЗМАХНУТЬ("..EPD.m.."/"..byt..")")

return {actionn} 
end,

    cellSelected = function(self, thisItem, action, cell)
        if action == actionn and cell ~= nil then
thisItem:getUser():getSprite():zap(cell)

if EPD.m  ~= 0 and EPD.m  <= byt then

if thisItem:isEquipped(RPD.Dungeon
.hero) then
local dst = thisItem:getUser():getPos()
local level = RPD.Dungeon.level
        local x = level:cellX(dst)
        local y = level:cellY(dst)
        for i = x - 1, x + 1 do
     for j = y - 1, y + 1 do
            local pos = level:cell(i,j)
 local soul =  RPD.Actor:findChar(pos)
            if soul and soul ~= RPD.Dungeon.hero then 
 RPD.affectBuff(soul, RPD.Buffs.Slow , 30*(l+1));
RPD.affectBuff(soul, RPD.Buffs.Poison , 30*(l+1));
RPD.affectBuff(soul, RPD.Buffs.Vertigo , 25*(l+1));
soul:getSprite():emitter():start(RPD.Sfx.ShadowParticle.CURSE, 0.02,4)
if not level.solid[pos] then
RPD.Sfx.CellEmitter:get(pos):start(RPD.Sfx.ShadowParticle.UP, 0.02, 20)
end
else
if not level.solid[pos] then
RPD.Sfx.CellEmitter:get(pos):start(RPD.Sfx.ShadowParticle.UP, 0.02, 20)
end
end
end
end

end

EPD.m  = EPD.m  - 1
storage.put("ja",EPD.m )

local dst = RPD.Ballistica:cast(thisItem:getUser():getPos(), cell, true, true, true)
local enemy = RPD.Actor:findChar(dst)
local l = thisItem:level()

RPD.playSound( "snd_badge.mp3" )

RPD.zapEffect(thisItem:getUser():getPos(),dst,"Shadow")
local level = RPD.Dungeon.level
        local x = level:cellX(dst)
        local y = level:cellY(dst)
        for i = x - 1-l, x + 1+l do
            for j = y - 1-l, y + 1+l do
            local pos = level:cell(i,j)
 local soul =  RPD.Actor:findChar(pos)
            if soul then 
 RPD.affectBuff(soul, RPD.Buffs.Slow , 30*(l+1));
RPD.affectBuff(soul, RPD.Buffs.Poison , 30*(l+1));
RPD.affectBuff(soul, RPD.Buffs.Vertigo , 25*(l+1));
soul:getSprite():emitter():start(RPD.Sfx.ShadowParticle.CURSE, 0.02,4)
if not level.solid[pos] then
RPD.Sfx.CellEmitter:get(pos):start(RPD.Sfx.ShadowParticle.UP, 0.02, 20)
end
else
if not level.solid[pos] then
RPD.Sfx.CellEmitter:get(pos):start(RPD.Sfx.ShadowParticle.UP, 0.02, 20)
end
end
end
end

else
RPD.glog("** Твоя палочка издаёт потрескивание: наверное, в ней кончились заряды.")
end

end
end,

    execute = function(self, item, hero, action)
        if actionn == action then
            item:selectCell(action,"Выбирите клетку")
        end
    end,
    bag = function(self, item)
        return "WandHolster"
    end

}