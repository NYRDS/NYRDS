--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 11,
            imageFile = "items/WandsMod.png",
            name      = "Жезл эфрита",
            info      = "От этого жезла веет аурой льда.",
            stackable = true,
            upgradable    = false,
             price     = 50,

equipable     = "left_hand"
        }
    end, actions = function() return {RPD.Actions.zap} end,
   
    execute = function(self,thisItem,hero, action) 
        if action == RPD.Actions.zap then
thisItem:getUser():getSprite():zap()
if thisItem:isEquipped(RPD.Dungeon
.hero) then
if math.random(1,3) == 1 then

--thisItem:detach(RPD.Dungeon.hero:getBelongings():getItem("NefritWand"))
thisItem:removeItemFrom(RPD.Dungeon.hero)
end
local level = RPD.Dungeon.level
        local hero = RPD.Dungeon.hero
  
            local mob = RPD.MobFactory:mobByName("IceNefrit")
local cell = hero:getPos()
            mob:setPos(cell)
      level:spawnMob(RPD.Mob:makePet(mob,RPD.Dungeon.hero))
else
if math.random(1,2) == 1   then 
thisItem:getUser():getSprite():zap()

local level = RPD.Dungeon.level
        local hero = RPD.Dungeon.hero
  
            local mob = RPD.MobFactory:mobByName("IceNefrit")
local cell = hero:getPos()
            mob:setPos(cell)
      level:spawnMob(RPD.Mob:makePet(mob,RPD.Dungeon.hero))
      else
      RPD.glog("Ничего не произошло")
end  
end
thisItem:detach(RPD.Dungeon.hero:getBelongings().backpack)
end
 end,
 bag = function(self, item)
        return "WandHolster"
    end

}
