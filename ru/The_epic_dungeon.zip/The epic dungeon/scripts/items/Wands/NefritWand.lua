--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 11,
            imageFile = "items/Wands.png",
            name      = "Жезл эфрита",
            info      = "От этого жезла веет аурой льда.",
            stackable = true,
            upgradable    = false,
             price     = 50
        }
    end, actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action, cell) 
        if action == RPD.Actions.zap then        local level = RPD.Dungeon.level
        local hero = RPD.Dungeon.hero
 
            local mob = RPD.MobFactory:mobByName("IceNefrit")
local cell = hero:getPos()
            mob:setPos(cell)
      level:spawnMob(RPD.Mob:makePet(mob,RPD.Dungeon.hero))    
            hero:eat(item,0,"Сущность Ледяной эфрит создана.")
end  
 end
}