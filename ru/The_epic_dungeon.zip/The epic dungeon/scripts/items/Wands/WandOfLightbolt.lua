--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

b = 4



return item.init{
    desc  = function() 
        return {
           image     = 0,
            imageFile = "items/WandsMod.png",
            name      = "Жезл светвого патрона",
            info      = "При использовании этот жезл выпустит снаряд мощного светового лазера.",
            stackable = false,
            upgradable    = true,
             price     = 50,
equipable     = "left_hand"
        }
    end, 

actions = function()


actionn = ("ВЗМАХНУТЬ("..EPD.a.."/"..b..")")

return {actionn} 
end,
    activate = function(self, item, hero)
                RPD.removeBuff(item:getUser(), RPD.Buffs.Light)

        RPD.permanentBuff(item:getUser(), RPD.Buffs.Light)
    end,

    deactivate = function(self, item, hero)
            RPD.removeBuff(item:getUser(), RPD.Buffs.Light)
    end,
    cellSelected = function(self, thisItem, action, cell)
        if action == actionn and cell ~= nil then
thisItem:getUser():getSprite():zap(cell)
if EPD.a  ~= 0 and EPD.a  <= b then

EPD.a  = EPD.a  - 1
storage.put("v",EPD.a )

local dst = RPD.Ballistica:cast(thisItem:getUser():getPos(), cell, true, true, true)
local enemy = RPD.Actor:findChar(dst)
if enemy then
RPD.affectBuff(enemy, RPD.Buffs.Light , 10*(thisItem:level()+1))
RPD.affectBuff(enemy, RPD.Buffs.Vertigo , 10*(thisItem:level()+1))
enemy:damage(RPD.Dungeon.depth*math.random(1,RPD.Dungeon.hero:magicLvl()),thisItem:getUser())
enemy:getSprite():emitter():burst( RPD.Sfx.ShadowParticle.UP, 8 )
RPD.zapEffect( thisItem:getUser():getPos(), enemy:getPos(), "DeathRay")
else
RPD.zapEffect( thisItem:getUser():getPos(), dst, "DeathRay")
end
else
RPD.glog("** Твоя палочка издаёт потрескивание: наверное, в ней кончились заряды.")
end

end
end,

    execute = function(self, item, hero, action)
        if actionn == action then
            item:selectCell(action,"Выбирите клетку")
        end
    end,
    bag = function(self, item)
        return "WandHolster"
    end,
mobWandUser = function(mob, to, level)
local dst = RPD.Ballistica:cast(mob:getPos(),to, true, true, true)
local enemy = RPD.Actor:findChar(dst)
if enemy then
RPD.affectBuff(enemy, RPD.Buffs.Light , 10*(level+1))
RPD.affectBuff(enemy, RPD.Buffs.Vertigo , 10*(level+1))
enemy:damage(RPD.Dungeon.depth*math.random(1,5),mob)
enemy:getSprite():emitter():burst( RPD.Sfx.ShadowParticle.UP, 8 )
RPD.zapEffect( mob:getPos(), enemy:getPos(), "DeathRay")
else
RPD.zapEffect( mob:getPos(), dst, "DeathRay")
end
end

}

