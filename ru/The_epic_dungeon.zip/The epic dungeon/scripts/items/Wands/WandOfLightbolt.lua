--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 0,
            imageFile = "items/Wands.png",
            name      = "Жезл светвого патрона",
            info      = "При использовании этот жезл выпустит снаряд мощного светового лазера.",
            stackable = false,
            upgradable    = false,
             price     = 50
        }
    end, 
actions = function() return
{RPD.Actions.zap} end,

    cellSelected = function(self, thisItem, action, cell)
        if action == RPD.Actions.zap then
 local enemy = RPD.Actor:findChar(cell)
  if enemy then
        RPD.affectBuff(enemy, RPD.Buffs.Light , 10)
        RPD.affectBuff(enemy, RPD.Buffs.Vertigo , 10)
        enemy:getSprite():emitter():burst( RPD.Sfx.ShadowParticle.UP, 8 )
        RPD.zapEffect( thisItem:getUser():getPos(), enemy:getPos(), "DeathRay")
        else
        RPD.zapEffect( thisItem:getUser():getPos(), cell, "DeathRay")
end
end
    end,

    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then
            item:selectCell(RPD.Actions.zap,"Выбирите клетку")
        end
    end,
}