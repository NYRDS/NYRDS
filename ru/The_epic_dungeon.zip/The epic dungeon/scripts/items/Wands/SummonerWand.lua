--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 12,
            imageFile = "items/Wands.png",
            name          = "Жезл призывателя",
            info          = "Этот жезл выглядит странно: верхушка светится ярко-красным цветом, сама палка обмотана жёлтой лентой с рунными узорами, а оканчивается эта красота красно-оранжевым шариком из адского камня.",
            stackable     = false,
            defaultAction = "Wand_ACZap",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action, cause )
        if action == RPD.Actions.zap then
        local level = RPD.Dungeon.level

        local hero = RPD.Dungeon.hero
        print(self, cause)

        for i = 1,2 do
            local mob = RPD.MobFactory:mobByName("Bee")
            local pos = level:getEmptyCellNextTo(hero:getPos())
            if (level:cellValid(pos)) then
                mob:setPos(pos)
level:spawnMob(RPD.Mob:makePet(mob,RPD.Dungeon.hero));
hero:setSoulPoints(-20)
        end
    end
  end
 end 

}