--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
            image         = 13,
            imageFile     = "items/Wands.png",
            name          = "Жезл дракона",
            info          = "Этот жезл очень большой: больше, чем твоя рука. Он состоит из какого-то непонятного материала. При использовании этот жезл наложит на уровень проклятье огня, которое будет активироваться в случайной точке.",
            stackable     = false,
            defaultAction = "Wand_ACZap",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action, cause )
        if action == RPD.Actions.zap then
       RPD.Dungeon.level:addScriptedActor(RPD.new(RPD.Objects.Actors.ScriptedActor,"scripts/actors/Burn"))
         end 
         end

}