--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

dod = 1


return item.init{ 
    desc  = function() 

        return { 
            image         = 13,
            imageFile     = "items/WandsMod.png",
            name          = "Жезл дракона",
            info          = "Этот жезл очень большой: больше, чем твоя рука. Он состоит из какого-то непонятного материала. При использовании этот жезл наложит на уровень проклятье огня, которое будет активироваться в случайной точке.",
            stackable     = false,
            defaultAction = "Wand_ACZap",

            price         = 50
     }
    end, 
actions = function()

actionn = ("ВЗМАХНУТЬ("..EPD.l.."/"..dod..")")

return {actionn} 
end,

    execute = function(self, thisItem, action)
        if actionn == action then
thisItem:getUser():getSprite():zap()

if EPD.l  ~= 0 and EPD.l  <= dod then

EPD.l  = EPD.l  - 1
storage.put("lcj",EPD.l )


       RPD.Dungeon.level:addScriptedActor(RPD.new(RPD.Objects.Actors.ScriptedActor,"scripts/actors/Burn"))

else 
RPD.glog("** Твоя палочка издаёт потрескивание: наверное, в ней кончились заряды.")
end

end
end,

--[[    execute = function(self, item, hero, action)
        if action == action then
            item:selectCell(action,"Выбирите клетку")
        end
    end,
--]]
    bag = function(self, item)
        return "WandHolster"
    end

}