--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

x = 4

if not storage.get("k") then
storage.put("k",EPD.i )
else
EPD.i = storage.get("k")
end

return item.init{
    desc  = function()  
    if not storage.get("Chars") then
storage.put("Chars",true)
        RPD.permanentBuff(RPD.Dungeon.hero, "Chars");
end

        return {
           image     = 6,
            imageFile = "items/WandsMod.png",
            name      = "Жезл инфузиса",
            info      = "При использовании этот жезл выпустит мощный разряд яда, который, расколовшись об первое же припядствие, создаст облако дурманящего газа..",
            stackable = false,
            upgradable    = true,
             price     = 50,
equipable     = "left_hand"

        }
    end, 
actions = function()

action = ("ВЗМАХНУТЬ("..EPD.i.."/"..x..")")

return {action} 
end,
    activate = function(self, item, hero)
                RPD.removeBuff(RPD.Dungeon.hero, "Poison")

        RPD.permanentBuff(RPD.Dungeon.hero, "Poison")
    end,
 
    deactivate = function(self, item, hero)
            RPD.removeBuff(RPD.Dungeon.hero, "Poison")
    end,

    cellSelected = function(self, thisItem, action, cell)
        if action == action and cell ~= nil then
thisItem:getUser():getSprite():zap(cell)

if EPD.i  ~= 0 and EPD.i  <= x then

EPD.i  = EPD.i  - 1
storage.put("k",EPD.i )

local dst = RPD.Ballistica:cast(thisItem:getUser():getPos(), cell, true, true, true)
local enemy = RPD.Actor:findChar(dst)
local lvl = thisItem:level()
RPD.zapEffect(thisItem:getUser():getPos(),dst,"LightZap")
EPD.ZapWand("WandOfPoison",RPD.Dungeon.depth+lvl,thisItem:getUser(),dst)
RPD.placeBlob( RPD.Blobs.ConfusionGas, dst, 60*(lvl+1))
RPD.playSound( "snd_crystal.mp3" )
RPD.Sfx.CellEmitter:get(dst):start(RPD.Sfx.Speck:factory( RPD.Sfx.Speck.LIGHT), 0.1,3);

else 
RPD.glog("** Твоя палочка издаёт потрескивание: наверное, в ней кончились заряды.")
end

end
end,

    execute = function(self, item, hero, action)
        if action == action then
            item:selectCell(action,"Выбирите клетку")
        end
    end,
    bag = function(self, item)
        return "WandHolster"
    end

}