--
-- User: mike
-- Date: 29.01.2019
-- Time: 20:33
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local hero = RPD.Dungeon.hero

bunus = 8

return item.init{

desc  = function ()
return {
image     = 3,
imageFile = "items/Helmets.png",
name       = "Чешуйчатый шлем",
info      = ("Шлем из соединённых вместе пластин обеспечивает достаточно хорошую защиту. Он даст тебе +"..bunus.." к броне."),
stackable = false,
upgradable    = true,
price     = 100,
equipable     = "left_hand"
}
end,

activate = function(self, item, hero)
RPD.removeBuff(item:getUser(),"Helmet")
RPD.permanentBuff(item:getUser(),"Helmet")
p = item:getUser():speed()
if hero:effectiveSTR() < 15-item:level() then
hero:speed(hero:speed()-(15-hero:effectiveSTR()))
end
level = item:level()
hero:dr(hero:dr()+8 + level)
end,

deactivate = function(self, item, hero)
RPD.removeBuff(item:getUser(),"Helmet")
hero:speed(p)
hero:dr(hero:dr()+8+level)
end,

typicalSTR  = function(self, item)
level = item:level()+1
bunus = 8+level
return 15 - item:level()
end,

requiredSTR = function(self, item)
return 15 - item:level()
end,
}
