--
-- User: mike
-- Date: 29.01.2019
-- Time: 20:33
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local hero = RPD.Dungeon.hero

bunus = 16

return item.init{

desc  = function ()
return {
image     = 1,
imageFile = "items/Helmets.png",
name       = "Готический шлем",
info      = ("Шлем, созданный самыми исскустными мастерами мира, обеспечивает непривзайдённую хорошую защиту. Он даст тебе +"..bunus.." к броне."),
stackable = false,
upgradable    = true,
price     = 200,
equipable     = "left_hand"
}
end,

activate = function(self, item, hero)
RPD.removeBuff(item:getUser(),"Helmet")
RPD.permanentBuff(item:getUser(),"Helmet")
p = item:getUser():speed()
if hero:effectiveSTR() < 20-item:level() then
hero:speed(hero:speed()-(20-hero:effectiveSTR()))
end
level = item:level()
hero:dr(hero:dr()+16 + level)
end,

deactivate = function(self, item, hero)
RPD.removeBuff(item:getUser(),"Helmet")
hero:speed(p)
hero:dr(hero:dr()+16+level)
end,

typicalSTR  = function(self, item)
level = item:level()+1
bunus = 16+level
return 20 - item:level()
end,

requiredSTR = function(self, item)
return 20 - item:level()
end,
}
