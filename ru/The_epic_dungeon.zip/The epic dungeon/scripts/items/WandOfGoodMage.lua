--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 35,
            imageFile = "items/materials.png",
            name      = "Жезл друида",
            info      = "При использовании этот жезл создаст жизненную энергию, способную как и навредть, так и воскреить... траву...",
            stackable = false,
            upgradable    = false,
             price     = 50
        }
    end, 
actions = function() return
{RPD.Actions.zap} end,

    cellSelected = function(self, thisItem, action, cell)
        if action == RPD.Actions.zap then
 local enemy = RPD.Actor:findChar(cell)
  if enemy then
        RPD.affectBuff(enemy, RPD.Buffs.Roots , 10)
        RPD.zapEffect( thisItem:getUser():getPos(), enemy:getPos(), "Ice")
RPD.placeBlob( RPD.Blobs.Regrowth , enemy:getPos(), 50 );
        else
        RPD.zapEffect( thisItem:getUser():getPos(), cell, "Ice")
RPD.placeBlob( RPD.Blobs.Regrowth ,cell, 50 );
end
end
    end,

    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then
            item:selectCell(RPD.Actions.zap,"Выбирите клетку")
        end
    end,
}