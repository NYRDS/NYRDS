--
-- User: mike
-- Date: 29.01.2019
-- Time: 20:33
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local Process = require "scripts/lib/Process"

local Ginerator = require "scripts/lib/Ginerator"

return item.init{
    desc  = function ()
        return {
            image     = 12,
            imageFile = "items/food.png",
            name      = "Test item",
            info      = "Item for script tests",
            stackable = true,
            defaultAction = "action1",
            price         = 7
        }
    end,
    actions = function() return {"action1","action2","action3"} end,

    cellSelected = function(self, thisItem, action, cell)
        if action == "action1" then
BloodSink = luajava.bindClass("com.nyrds.pixeldungeon.effects.emitters.BloodSink")
BloodSink.BloodSink(cell)
Process.beckon_player = cell
end
        if action == "action3" then
            RPD.glogp("performing "..action.."on cell"..tostring(cell).."\n") 
--[[
RPD.Sfx.MagicMissile:purpleLight(thisItem:getUser():getSprite():getParent(),thisItem:getUser():getPos(),cell,Callback.callback)
--]]
if RPD.Actor:findChar(cell) then
Process.beckon_player = 724
RPD.Actor:findChar(cell):beckon(724)
end
local Callback = luajava.bindClass("com.watabou.utils.Callback")
missile = thisItem:getUser():getSprite():getParent():recycle(RPD.Sfx.MagicMissile)
missile:reset( thisItem:getUser():getPos(),cell,Callback.callback)
missile:size(1);
--missile:pour( RPD.Sfx.EnergyParticle.FACTORY, 0.01f);
missile:pour(RPD.Sfx.Speck:factory(RPD.Sfx.Speck.COIN  ), 0.01)
        end
        if action == "action2" then
local heap = RPD.Dungeon.level:getHeap(cell)
t = RPD.packEntity(heap)
RPD.unpackEntity(t)
RPD.glog(t)
RPD.glogp("performing "..action.."on cell"..tostring(cell).."\n")
       end
    end,

    execute = function(self, item, hero, action)
        if action == "action1" then
            item:selectCell("action1","Please select cell for action 1")
        end

        if action == "action2" then
            item:selectCell("action2","Please select cell for action 1")
        end

        if action == "action3" then
            item:selectCell("action3","Please select cell for action 1")
        end
    end,
}
