--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--0xFFFFFF

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"


return item.init{
    desc  = function ()
        return {
        doUnequip = true,
           image     = 4,
            imageFile = "items/materials.png",
            name      = "Ледяной жезл",
            info      = "Жезл состоит из цельного куска льда. Не дают растаять ему три кристалла на вершине. При использовании он заморозит всё возле героя.",
            stackable = false,
            upgradable    = false,
 
             price     = 50
        }
    end, actions = function()

 return {RPD.Actions.zap}
end,

    execute = function(self, item, hero, action, cell, char, data) 
         if action == RPD.Actions.zap then
local json = require("scripts/lib/json")

test = json.encode(
{
defenseSkill = 1,
attackSkill = 1,
exp = 1,
maxLvl = 1,
dmgMin = 1,
dmgMax = 1,
dr = 1,
baseSpeed = 2,
attackDelay = 1,
ht = 55555,
viewDistance = 1,
name = "Black Rat",
name_objective = "Black Rat",
description = "Just a common house rat, not marsupial",
gender = "feminine",
spriteDesc = "spritesDesc/BlackRat.json",
walkingType = "NORMAL"
}
)
RPD.glog(RPD.Dungeon:currentPosition() )
--[[
RPD.MobFactory:registerMobClass("test")
local mob = RPD.MobFactory:mobByName("test")
mob:setPos(item:getUser():getPos())
RPD.Dungeon.level:spawnMob(mob)
--]]
end 
end 
}
