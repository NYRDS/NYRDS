--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--0xFFFFFF

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

return item.init{
    desc  = function ()
        return {
           image     = 4,
            imageFile = "items/materials.png",
            name      = "Ледяной жезл",
            info      = "Жезл состоит из цельного куска льда. Не дают растаять ему три кристалла на вершине. При использовании он заморозит всё возле героя.",
            stackable = false,
            upgradable    = false,
 
             price     = 50
        }
    end, actions = function()
 return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action, cell, char, data) 
         if action == RPD.Actions.zap then          
--RPD.affectBuff(RPD.Dungeon.hero,"Greed", 100);
--RPD.golog(dofile("scripts/items/Tests/Test1.lua"))
--RPD.Dungeon.level:addScriptedActor(RPD.new(RPD.Objects.Actors.ScriptedActor,"scripts/actors/Test"))
local level = RPD.Dungeon.level
for i = 0,RPD.Dungeon.level:getLength()-1 do           
local maybeMob = RPD.Actor:findChar(i)          
    if maybeMob and maybeMob ~= RPD.Dungeon.hero then 
maybeMob:damage(10000, RPD.Dungeon.hero)
end
end
end
end 
}