--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 7,
            imageFile = "items/wands_remastered.png",
            name      = "Жезл хаоса",
            info      = "Жезл целиком состоит из адского камня, с вырезанными на нём заклинаниями.",
            stackable = true,
            upgradable    = false,
 
             price     = 45
        }
    end, actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action, cell)
        if action == RPD.Actions.zap then 
local blobs = {
    RPD.Blobs.Fire,
 RPD.Blobs.Regrowth,
RPD.Blobs.ToxicGas, RPD.Blobs.ConfusionGas,
RPD.Blobs.ParalyticGas
}
       local level = RPD.Dungeon.level
        local hero = RPD.Dungeon.hero
        print(self, cause)

        for i = 1,2 do
              local pos = level:getEmptyCellNextTo(hero:getPos())
            if (level:cellValid(pos)) then      RPD.placeBlob( blobs[math.random(1,5)], pos, 50 );
 hero:setSoulPoints(-20)
         end
    end
  end
 end 

        
}
    

