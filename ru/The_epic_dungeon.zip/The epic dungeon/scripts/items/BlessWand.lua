--
-- User: mike
-- Date: 29.01.2019
-- Time: 20:33
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local hero = RPD.Dungeon.hero
return item.init{
    desc  = function ()
        return {
            image         = 21,
            imageFile     = "items/wands_remastered.png",
            name          = "Жезл света",
            info          = "Этот жезл выглядит довольно красиво: он светится ярко-жёлтым светом, на его вершине находится хрусталь. Подобный жезл ты видел у епископа.",
            stackable     = false,
            defaultAction = "Wand_ACZap",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.zap} end,

    cellSelected = function(self, thisItem, action, cell)
        if action == RPD.Actions.zap then 
                local soul =  RPD.Actor:findChar(cell)
                if soul then
        RPD.affectBuff(soul, RPD.Buffs.Blessed , 100);
        soul:getSprite():emitter():burst( RPD.Sfx.ShaftParticle.FACTORY, 5)

   else
     RPD.Sfx.CellEmitter:get(cell):burst( RPD.Sfx.ShaftParticle.FACTORY, 5)
end
end
end,
    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then
            item:selectCell( RPD.Actions.zap ,"Кого благословить?")
        end
end
}
