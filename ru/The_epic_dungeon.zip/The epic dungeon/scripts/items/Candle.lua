--
-- User: mike
-- Date: 29.01.2019
-- Time: 20:33
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local hero = RPD.Dungeon.hero
return item.init{
    desc  = function ()
        return {
           image     = 13,
            imageFile = "items/materials.png",
            name      = "Свеча",
            info      = "Обычная свеча.",
            stackable = false,
            upgradable    = false,
             price     = 50
        }
    end,
    actions = function() return {"ЗАЖЕЧЬ"} end,

    execute = function(self, item, hero, action)
        if action == "ЗАЖЕЧЬ" then
   RPD.affectBuff(RPD.Dungeon.hero, RPD.Buffs.Light , 100)
item:detach(RPD.Dungeon.hero:getBelongings().backpack)
end
end
}
