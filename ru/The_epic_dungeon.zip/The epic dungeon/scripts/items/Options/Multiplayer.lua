--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local Multiplayer = require "scripts/lib/Multiplayer"

local User = require "scripts/User"

local Process = require "scripts/lib/Process"

return item.init{
    desc  = function ()
        return {
           image     = 9,
            imageFile = "items/ArtifactsMod.png",
            name      = "Мультиплеер",
            info      = "Этот предмет позволяет соедениться с другим игроком, который прописан как хост или игрок. У другого человека должно быть тоже самое. Сейчас этот режим можно назвать 'Демо-версией' , так что не судите строго. Функция 'Включить отображение' спавнит энписи, который повторяет все движения другого игрока. Этота функция накладывает бафф на героя и передаёт каждый ход данные другому игроку. Таким образом, если вы- хост, то после нажатия вы должны сказать другому игроку, чтобы он подключился тоже. Затем вы должны пропустить ход (можно несколько), после этого другой игрок должен тоже пропустить ход. Если ничего не получилось, попробуйте занаво. 'Передать предмет' или 'Передать моба' отправляет данные другому игроку. Причём как правило первые предметы или мобы бесследно исчезают. Принимая предмет или моба, повторяйте попытку 5-10 раз, если ничего не получилось, то скорее всего предмет или моб пропал ;). Также следует помнить, что передовать мобов и предметов из мода тоже не следует. Данные могут отставать, поэтому передавать мобов и предметы не следует, когда включено отображение. Думаю, что не сложно догадаться, что для нормальной работы нужен интернет. Перед игрой вам нужно настроить подключение: записать хоста и игрока. Увы, но если ваши ники совпадут с никами других людей, то данные перемешаются.",
            stackable = true,
            upgradable    = false,
            price     = 0
             }
    end,
    actions = function() return {"МУЛЬТИПЛЕЕР"} end,
    execute = function(self, item, hero, action)
if action == "МУЛЬТИПЛЕЕР" then
user = item:getUser()

local select = function(index)
if index == 0 then

if User.status == User.host then
if User.player == User.host then
RPD.glog("-- Ошибка: у пользователя и хоста одинаковый ник")
return
end
if Process.multiplayer_start ~= nil then
RPD.glog("-- Ошибка: мультиплеер уже создан")
return
end
if RPD.RemixedDungeon:getDifficulty() <= 1 then
RPD.glog("-- Ошибка: мультиплеер может быть создан только на сложности более чем обычный с сохранениями")
return
end
Process.multiplayer_start = true
RPD.permanentBuff(user,"Multiplayer/Multiplayer_host")
RPD.glog("++ ".."Игра создана! Вы- хост с ником "..User.host.." и передаёте данные игроку с ником "..User.player.."! Удачной игры!")
end
if User.status == User.player then
if User.player == User.host then
RPD.glog("-- Ошибка: у пользователя и хоста одинаковый ник")
return
end
if Process.multiplayer_start ~= nil then
RPD.glog("-- Ошибка: игра уже запущена")
return
end
if RPD.RemixedDungeon:getDifficulty() <= 1 then
RPD.glog("-- Ошибка: мультиплеер может быть создан только на сложности более чем обычный с сохранениями")
return
end
Process.multiplayer_start = true
RPD.permanentBuff(user,"Multiplayer/Multiplayer_player")
RPD.glog("++ ".."Игра запущена! Вы- игрок с ником "..User.player.." и передаёте данные хосту с ником"..User.host.."! Удачной игры!")
end
end
if index == 1 then
RPD.glog("Этого режима пока нет.")
end
if index == 2 then

select_nik = function(index)
if index == 0 then

select_player = function(index)
if index == 0 then
RPD.System.Input:showInputDialog("Игрок", ("Введите ник игрока, сейчас игрок имеет ник "..User.player))
RPD.chooseOption( 
select_player,
("Игрок: "..User.player),
"Выберите функцию",
"Изменить",
"Сохранить изменения"
)
end
if index == 1 then
User.player = RPD.System.Input:getInputString()
RPD.chooseOption( 
select_nik,
"Настроить подключение",
"Выберите функцию",
("Игрок: "..User.player),
("Хост: "..User.host),
("Ник твоего статуса: "..User.status)
)
end
end
RPD.chooseOption( 
select_player,
("Игрок: "..User.player),
"Выберите функцию",
"Изменить",
"Сохранить изменения"
)
end

if index == 1 then

select_host = function(index)
if index == 0 then
RPD.System.Input:showInputDialog("Хост", ("Введите ник хоста, сейчас ваш хост имеет ник "..User.host))
RPD.chooseOption( 
select_host,
("Хост: "..User.host),
"Выберите функцию",
"Изменить",
"Сохранить изменения"
)
end
if index == 1 then
User.host = RPD.System.Input:getInputString()
RPD.chooseOption( 
select_nik,
"Настроить подключение",
"Выберите функцию",
("Игрок: "..User.player),
("Хост: "..User.host),
("Ник твоего статуса: "..User.status)
)
end
end
RPD.chooseOption( 
select_host,
("Хост: "..User.host),
"Выберите функцию",
"Изменить",
"Сохранить изменения"
)
end
if index == 2 then

select_status = function(index)
if index == 0 then
RPD.System.Input:showInputDialog("Кем вы являетесь в этом подключении?", ("Введите ник хоста или игрока- кем вы являетесь в этом подключении. Сейчас вы прописаны как "..User.status))
RPD.chooseOption( 
select_status,
("Вы: "..User.status),
"Выберите функцию",
"Изменить",
"Сохранить изменения"
)
end
if index == 1 then
User.status = RPD.System.Input:getInputString()
RPD.chooseOption( 
select_nik,
"Настроить подключение",
"Выберите функцию",
("Игрок: "..User.player),
("Хост: "..User.host),
("Ник твоего статуса: "..User.status)
)
end
end
RPD.chooseOption( 
select_status,
("Вы: "..User.status),
"Выберите функцию",
"Изменить",
"Сохранить изменения"
)
end
end
RPD.chooseOption( 
select_nik,
"Настроить подключение",
"Выберите функцию",
("Игрок: "..User.player),
("Хост: "..User.host),
("Ник твоего статуса: "..User.status)
)
end
if index == 3 then
RPD.removeBuff(user,"Multiplayer/Multiplayer_player")
RPD.removeBuff(user,"Multiplayer/Multiplayer_host")
for i = 1, RPD.Dungeon.level:getLength() do
local maybeMob = RPD.Actor:findChar(i)
if maybeMob and maybeMob ~= RPD.Dungeon.hero and maybeMob:getMobClassName() == "Multiplayer/Player" then
maybeMob:destroy()
maybeMob:getSprite():killAndErase()
end
end
if Process.multiplayer_start == true then
Process.multiplayer_start = nil
RPD.glog("++ Вы успешно отключились!")
else
RPD.glog("++ Вы успешно отключились, хотя и не были подключены!")
end
end
if index == 4 then
item:selectCell("МУЛЬТИПЛЕЕР","Выбирете предмет")
end
if index == 5 then
item:selectCell("МУЛЬТИПЛЕЕРР","Выбирете существо")
end
if index == 6 then
Multiplayer.hero:receiveItem()
end
if index == 7 then
Multiplayer.hero:receiveMob()
end
end
RPD.chooseOption( 
select,
"Мультиплеер",
"Выберите функцию",
"Включить отображение",
"Общий мультиплеер",
"Настроить подключение",
"Отключить отображение",
"Передать предмет",
"Передать существо",
"Принять предмет",
"Принять существо"
)

        end
    end,
cellSelected = function(self, thisItem, action, cell)

if action == "МУЛЬТИПЛЕЕР" then
local itemGive = RPD.Dungeon.level:getHeap(cell)
if not itemGive then
RPD.glog("Здесь ничего нет")
return
end
if itemGive then

select_item = function(index)
if index == 0 then
item = RPD.Dungeon.level:getHeap(cell):peek()
--RPD.Dungeon.hero:collect(RPD.ItemFactory:itemByName(item:getClassName()))
Process.item = RPD.packEntity(item)
Multiplayer.hero:sendItem()
itemGive:pickUp()
RPD.glog("++ Вы отдали "..item:name())
end
if index == 1 then
return
end
end
RPD.chooseOption( 
select_item,
"Передача предмета",
"Вы уверены, что хотите передать вашему союзнику?",
"Да",
"Нет"
)
end
end
if action == "МУЛЬТИПЛЕЕРР" then
char = RPD.Actor:findChar(cell)
if char and char ~= RPD.Dungeon.hero then
if char:isPet() then
RPD.glog("++ Вы передали питомца в подчинение своему союзнику")
Process.pet = RPD.packEntity(char)
Multiplayer.hero:sendMob()
char:destroy()
char:getSprite():killAndErase()
else
RPD.glog("-- Это существо вам не подчиняется")
end
end
end
end
}
