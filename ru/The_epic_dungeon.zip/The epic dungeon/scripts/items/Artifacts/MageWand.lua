--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

return item.init{
    desc  = function()

        return {
           image     = 3,
            imageFile = "items/ArtifactsMod.png",
            name      = "Посох мага",
            info      = "Этот посох сделан из особого магического дерева. Он излучает магическую ауру, но не может использовать её. Посох может принять вид жезла, если поймёт как устроена его стихия.",
            stackable = true,
            price     = 0,
equipable     = "weapon"
        }
    end, 
    activate = function(self, item, hero)
                RPD.removeBuff(item:getUser(), RPD.Buffs.Light)

        RPD.permanentBuff(item:getUser(), RPD.Buffs.Light)

--RPD.removeBuff(item:getUser(), "Weapons/MageWand")

--RPD.permanentBuff(item:getUser(), "Weapons/MageWand")

    end,

    deactivate = function(self, item, hero)
            RPD.removeBuff(item:getUser(), RPD.Buffs.Light)
--RPD.removeBuff(item:getUser(), "Weapons/MageWand")
    end,

bag = function(self, item)
        return "WandHolster"
    end,
attackProc = function(self,enemy,dmg)
RPD.Sfx.MagicMissile:whiteLight(RPD.Dungeon.hero:getSprite():getParent(),RPD.Dungeon.hero:getPos(),RPD.Dungeon.hero:getNearestEnemy():getPos(),nil)
RPD.Dungeon.hero:getNearestEnemy():damage(math.random(3,4),RPD.Dungeon.hero)
end,
getAttackAnimationClass = function()
return "sword"
end

}