--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

return item.init{
    desc  = function ()
        return { 
           image     = 3,
            imageFile = "items/Artifacts.png",
            name      = "Посох мага",
            info      = "Этот посох сделан из особого магического дерева. Он излучает магическую ауру, но не может использовать её. Посох может принять вид жезла, если поймёт как устроена его стихия.",
            stackable = true,
            price     = 0
        }
    end,
    burn   = function() return RPD.ItemFactory:itemByName("FireWand") end,
    freeze = function() return RPD.ItemFactory:itemByName("IceWand") end,
    poison = function() return RPD.ItemFactory:itemByName("BlackWand") end
}
