--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

local hero = RPD.Dungeon.hero

return item.init{
    desc  = function ()
        return {
           image     = 27,
            imageFile = "items/materials.png",
            name      = "Смергл",
            info      = "Именно так это оружие выглядит в этой игре. Это ещё раз подтверждает, насколько Magic Rampage странная игра.",
            stackable = true,
            price     = 10
        }
    end,
    onThrow = function(self, item, cell )
                local soul =  RPD.Actor:findChar(cell)
                if soul then
RPD.placePseudoBlob( RPD.PseudoBlobs.Freezing, cell)   
hero:collect(item)
RPD.zapEffect(hero:getPos(), cell, "Ice") 
RPD.Sfx.CellEmitter:get(cell):start(RPD.Sfx.SnowParticle.FACTORY, 0.08, 20)
    else
RPD.placePseudoBlob( RPD.PseudoBlobs.Freezing, cell)   
hero:collect(item)
RPD.zapEffect(hero:getPos(), cell, "Ice")
RPD.Sfx.CellEmitter:get(cell):start(RPD.Sfx.SnowParticle.FACTORY, 0.08, 20)
end
    end 
}