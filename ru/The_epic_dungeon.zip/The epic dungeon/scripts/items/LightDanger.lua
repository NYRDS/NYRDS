--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 21,
            imageFile = "items/materials.png",
            name      = "Кинжал света",
            info      = "Лезвие этого кинжала сделано из хрусталя, на рукояди из железа есть еле заметные узоры. Интересно, зачем он нужен?",
            stackable = true,
            price     = 10
        }
    end,
    onThrow = function(self, item, cell )
                local soul =  RPD.Actor:findChar(cell)
                if soul then
        RPD.affectBuff(soul, RPD.Buffs.Vertigo , 10);
 RPD.affectBuff(soul, RPD.Buffs.Light , 10);
        soul:getSprite():emitter():burst( RPD.Sfx.ShadowParticle.UP, 8 )
    else
           item:dropTo(cell)
end
end
}