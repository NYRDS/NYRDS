--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 0,
            imageFile = "items/BookOfScrolls.gif",
            name          = "Свиток стихий",
            info          = "При использовании этот свиток создаст случайного элементаля рядом с героем.",
            stackable     = true,
            defaultAction = "Scroll_ACRead",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.read} end,
    execute = function(self, item, hero, action, cause )
        if action == RPD.Actions.read then

local wands = 
{
"BlankScroll",
"ScrollOfMagicMapping",
"ScrollOfRecharging",
"ScrollOfLullaby",
"ScrollOfCurse",
"ScrollOfWeaponUpgrade",
"ScrollOfIdentify",
"ScrollOfUpgrade",
"ScrollOfChallenge",
"ScrollOfMirrorImage",
"ScrollOfTeleportation",
"ScrollOfDomination",
"ScrollOfRemoveCurse",
"ScrollOfPsionicBlast"
}
        local level = RPD.Dungeon.level

        local hero = RPD.Dungeon.hero
            local wand = RPD.ItemFactory:itemByName(wands[math.random(1,14)])
            local pos = level:getEmptyCellNextTo(hero:getPos())
            if (level:cell(pos)) then
 
RPD.Dungeon.level:drop(wand, pos)
    end
  end
 end 

}