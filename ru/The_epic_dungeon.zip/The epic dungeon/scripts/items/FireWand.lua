--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 2,
            imageFile = "items/wands_remastered.png",
            name      = "Огненный жезл",
            info      = "Этот жезл содержит в себе магию огня, которая готова вот-вот вырваться наружу. При использовании поджигает 1-2 клетки возле героя.",
            stackable = true,
            upgradable    = false,
 
             price     = 45
        }
    end, actions = function() return {RPD.Actions.zap} end,
    execute = function(self, item, hero, action, cell)
        if action == RPD.Actions.zap then      
        local level = RPD.Dungeon.level
        local hero = RPD.Dungeon.hero
if hero:getSoulPoints() < 20 then
RPD.glogn("Не хватает маны")
return false
end
if hero:getSoulPoints() >= 20 then
        print(self, cause)
 hero:setSoulPoints(math.min( hero:getSoulPoints()-20,20))
        for i = 1,2 do
              local pos = level:getEmptyCellNextTo(hero:getPos())
            if (level:cellValid(pos)) then      RPD.placeBlob( RPD.Blobs.Fire , pos, 50 );
         end
    end
  end
 end 
end
        
}
    

