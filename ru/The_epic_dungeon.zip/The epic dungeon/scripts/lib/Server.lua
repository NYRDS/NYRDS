local RPD = require "scripts/lib/commonClasses"

local Multiplayer = require "scripts/lib/commonClasses"

local Server = {
client = nil,
connect = function()
SClientLua = luajava.bindClass("com.nyrds.pixeldungeon.networking.SClientLua")
client = SClientLua:createNew( "37.194.195.213" ,3002):connect()
end,

sendData = function (text)
RPD.glog(text)
client:sendMessage("text")
end,

receiveData = function()
while not client:canReceive() do
end
return client:receiveMessage()
end,

stop = function()
if client ~= nil then
client:stop()
end
end
}
return Server