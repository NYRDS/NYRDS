local Process = {
multiplayer_start = nil,
beckon_player = nil,
was = false,
life = nil,
ht = nil,
hp = nil,
pos = nil,
class = nil,
depth = nil,
item = nil,
pet = nil
}
return Process