local RPD = require "scripts/lib/commonClasses"
  
local Server = require "scripts/lib/Server"

local User = require "scripts/User"

local Process = require "scripts/lib/Process"

if User.status == User.host then
Cstatus = User.player --User.player
else
Cstatus = User.host
end


local hero = {

sendItem = function()

if Process.item == nil then
return
end

if client == nil then
SClientLua = luajava.bindClass("com.nyrds.pixeldungeon.networking.SClientLua")
client = SClientLua:createNew( "37.194.195.213" ,3002):connect()
end

item = tostring(Process.item)
Process.item = nil

user = Cstatus

v = table.concat({user,"it",item}," ")
client:sendMessage(v)
end,


receiveItem = function()

if client == nil then
SClientLua = luajava.bindClass("com.nyrds.pixeldungeon.networking.SClientLua")
client = SClientLua:createNew( "37.194.195.213" ,3002):connect()
end

time = 0
while not client:canReceive() do
if time == 100000 then
RPD.glog("-- Время вышло:скорее всего вам никто ничего не передавал.")
return 
end
time = time + 1
end
data = client:receiveMessage();

sep = "%s"
t={}
i=1
for str in string.gmatch(data, "([^"..sep.."]+)") do
t[i] = str
i = i + 1
end

-- если это мне
if t[1] == User.status then

if t[2] == "it" then

-- передача предмета
if t[3] ~= "nil" then
local item = RPD.unpackEntity(t[3])
RPD.Dungeon.hero:collect(item)
RPD.glog("++ "..Cstatus.." передал вам "..item:name())
end
end

end
--client:stop()
end,

sendMob = function()

if Process.pet == nil then
return
end

if client == nil then
SClientLua = luajava.bindClass("com.nyrds.pixeldungeon.networking.SClientLua")
client = SClientLua:createNew( "37.194.195.213" ,3002):connect()
end

mob = tostring(Process.pet)
Process.pet = nil

user = Cstatus

v = table.concat({user,"mb",mob}," ")
client:sendMessage(v)
end,


receiveMob = function()

if client == nil then
SClientLua = luajava.bindClass("com.nyrds.pixeldungeon.networking.SClientLua")
client = SClientLua:createNew( "37.194.195.213" ,3002):connect()
end

time = 0
while not client:canReceive() do
if time == 100000 then
RPD.glog("-- Время вышло:скорее всего вам никто никого не передавал.")
return 
end
time = time + 1
end
data = client:receiveMessage();

sep = "%s"
t={}
i=1
for str in string.gmatch(data, "([^"..sep.."]+)") do
t[i] = str
i = i + 1
end

-- если это мне
if t[1] == User.status then

if t[2] == "mb" then

-- передача моба
if t[3] ~= "nil" then
local mob = RPD.unpackEntity(t[3])
local pos = RPD.Dungeon.level:getEmptyCellNextTo(RPD.Dungeon.hero:getPos())
mob:setPos(pos)
RPD.Dungeon.level:spawnMob(mob)
end

end
end
--client:stop()
end,


sendData = function()

if client == nil then
SClientLua = luajava.bindClass("com.nyrds.pixeldungeon.networking.SClientLua")
client = SClientLua:createNew( "37.194.195.213" ,3002):connect()
end

-- жив ли я
if RPD.Dungeon.hero:hp() > 0 then
life = true
else
life = false
end

-- сколько у меня может быть хп
ht = RPD.Dungeon.hero:ht()

-- сколько у меня хп
hp = RPD.Dungeon.hero:hp()

-- моя позиция
pos = RPD.Dungeon.hero:getPos()

-- мой класс
class = RPD.Dungeon.hero:getHeroClass()

-- на какой я глубине
depth = RPD.Dungeon.depth

v = table.concat({tostring(life),tostring(ht),tostring(hp),tostring(pos),tostring(class),tostring(depth),User.status}," ")
--RPD.glog(v)
client:sendMessage(v)
end,



receiveData = function()

while not client:canReceive() do
end
data = client:receiveMessage();

sep = "%s"
t={}
i=1
for str in string.gmatch(data, "([^"..sep.."]+)") do
t[i] = str
i = i + 1
end

-- если это мне
if t[7] == Cstatus then

-- если данные уже когда-то были получены
if Process.was then

-- если было изменение в макс хп
if Process.ht ~= t[2] then

-- поиск изображения
for i = 1,RPD.Dungeon.level:getLength()-1 do           
local maybeMob = RPD.Actor:findChar(i)

-- если оно найдено
if maybeMob and maybeMob ~= RPD.Dungeon.hero and maybeMob:getMobClassName() == name then
maybeMob:ht(tonumber(t[2]))
end
end
end

-- если было изменение в хп
if Process.hp ~= t[3] then

-- поиск изображения
for i = 1,RPD.Dungeon.level:getLength()-1 do           
local maybeMob = RPD.Actor:findChar(i)

-- если оно найдено
if maybeMob and maybeMob ~= RPD.Dungeon.hero and maybeMob:getMobClassName() == name then

-- если было в плюс
if tonumber(Process.hp) < tonumber(t[3]) then
maybeMob:heal(tonumber(t[3])-tonumber(Process.hp),RPD.Dungeon.hero)
else

-- если было в минус
maybeMob:damage(tonumber(Process.hp)-tonumber(t[3]),RPD.Dungeon.hero)
end
end
end
end
end

-- обновление данных
Process.was = true
Process.life = t[1]
Process.ht = t[2]
Process.hp = t[3]
Process.pos = t[4]
Process.class = t[5]
Process.depth = t[6]

-- сокращяем
local life = Process.life
local ht = tonumber(Process.ht)
local hp = tonumber(Process.hp)
local pos = tonumber(Process.pos)
local depth = tonumber(Process.depth)
local class = Process.class

-- определение класса героя
local HeroClass = luajava.bindClass("com.watabou.pixeldungeon.actors.hero.HeroClass")
if class == tostring(HeroClass.NECROMANCER) then
name = "Heroes/Player_Necromanter"
elseif class == tostring(HeroClass.ROGUE) then
name = "Heroes/Player_Rogue"
elseif class == tostring(HeroClass.HUNTRESS) then
name = "Heroes/Player_Hantress"
elseif class == tostring(HeroClass.WARRIOR) then
name = "Heroes/Player_Warror"
elseif class == tostring(HeroClass.GNOLL) then
name = "Heroes/Player_Gnoll"
elseif class == tostring(HeroClass.ELF) then
name = "Heroes/Player_Elf"
elseif class == tostring(HeroClass.MAGE) then
name = "Heroes/Player_Mage"
end

-- если я жив то
if life == "true" then

-- поиск изображения
for i = 1,RPD.Dungeon.level:getLength()-1 do           
local maybeMob = RPD.Actor:findChar(i)

-- если оно найдено
if maybeMob and maybeMob ~= RPD.Dungeon.hero and maybeMob:getMobClassName() == name then

-- если оно может существовать
if RPD.Dungeon.depth == depth then
Process.beckon_player = pos
else
maybeMob:destroy()
maybeMob:getSprite():killAndErase()
end
break
end
-- если оно не найдено
if i == RPD.Dungeon.level:getLength()-2 then

-- если оно может существовать
if RPD.Dungeon.depth == depth then

local mob = RPD.MobFactory:mobByName(name)
mob:setPos(pos)
RPD.Dungeon.level:spawnMob(mob);
break
end
end

end

--[[
-- закрытие если хост выше или на этом этаже
for i = 1,RPD.Dungeon.level:getLength()-1 do         
if depth <= RPD.Dungeon.depth then
if RPD.Dungeon.level.map[i] == RPD.Terrain.EXIT or RPD.Dungeon.level[i] == 25 then
RPD.Dungeon.level:set(i-1, 4)
end
end
end

-- открытие если хост ниже этого этажа
for i = 1,RPD.Dungeon.level:getLength()-1 do         
if depth > RPD.Dungeon.depth then
if RPD.Dungeon.level.map[i] == RPD.Terrain.EXIT or RPD.Dungeon.level[i] == 25 then
RPD.Dungeon.level:set(i-1, RPD.Terrain.EXIT)
end
end
end
--]]
else

RPD.glog("Ваш товарищ скончался")
end

end

--RPD.glog(v)
----client:stop()

end
}

local Multiplayer = {
hero = hero,
level = level
}
return Multiplayer

