local RPD  = require "scripts/lib/commonClasses"
local EPD =
{
IceBlock = luajava.bindClass("com.watabou.pixeldungeon.effects.IceBlock"),
MakePets = function()
for i = 0,RPD.Dungeon.level:getLength()-1 do                local maybeMob = RPD.Actor:findChar(i)          
    if maybeMob and maybeMob ~= RPD.Dungeon.hero then 
        RPD.Mob:makePet(maybeMob, RPD.Dungeon.hero)
    end
end
end,
local objectFactory = luajava.bindClass("com.nyrds.pixeldungeon.levels.objects.LevelObjectsFactory");
}

return EPD