local RPD  = require "scripts/lib/commonClasses"
local EPD =
{
IceBlock = luajava.bindClass("com.watabou.pixeldungeon.effects.IceBlock"),
a = 0,
b = 0,
c = 0,
d = 0,
i = 0,
f = 0,
g = 0,
h = 0,
e = 0,
j = 0,
k = 0,
l = 0,
m = 0,
time = 1,
ZapWand = function(Wand,level,user,cell)

local Wand = RPD.creteItem(Wand, {level = level})
Wand:mobWandUse(user,cell)

end,
SpawnMob = function(mob,pos,pet,time)
local maybeMob = RPD.MobFactory:mobByName(mob)
maybeMob:setPos(pos)
if time then
RPD.affectBuff(maybeMob, "Time" , 10)
end
if pet then
RPD.Dungeon.level:spawnMob(RPD.Mob:makePet(maybeMob,RPD.Dungeon.hero));
else
RPD.Dungeon.level:spawnMob(maybeMob)
end
end,

MakePets = function()
for i = 0,RPD.Dungeon.level:getLength()-1 do                local maybeMob = RPD.Actor:findChar(i)          
    if maybeMob and maybeMob ~= RPD.Dungeon.hero then 
        RPD.Mob:makePet(maybeMob, RPD.Dungeon.hero)
    end
end
end,

Klak = function(cell,min,max,user,chanse, dartion, cast)
b = 0
mana = RPD.Dungeon.hero:getSkillPoints()
local level = RPD.Dungeon.level
local W = level:getWidth()
local wall = RPD.Terrain.WALL
local wall2 = RPD.Terrain.WALL_DECO
local wall3 = RPD.Terrain.STATUE_SP
local wall4 = RPD.Terrain.STATUE
local wall5 = RPD.Terrain.BOOKSHELF

KlakCell = function(cell)
 
if cast == true then
if mana > b then
RPD.Dungeon.hero:spendSkillPoints(b)
else
RPD.glog("** Не хватает маны")
return
end
end

local mob = RPD.Actor:findChar(a)
if mob and mob ~= user then
if math.random(1,chanse) == 1 then
RPD.affectBuff(mob, RPD.Buffs.Cripple , dartion)
end
mob:damage(math.random(min,max),user)
b = b +1
RPD.topEffect(cell,"Klak")
if user == RPD.Dungeon.hero then
user:spend(1)
end
else
if user == RPD.Dungeon.hero then
user:spend(1)
end
b = b+1
RPD.topEffect(cell,"Klak")
end
end


a = user:getPos()
a_y = level:cellY(a) 
cell_y = level:cellY(cell) 
a_x = level:cellX(a) 
cell_x = level:cellX(cell) 

while (a ~= cell) do

if level.solid[a] then
break
end

if cell ~= nil then

if cell < a then

if a_y == cell_y then
while a ~= cell do
if level.solid[a] then
break
end
a = a-1
KlakCell(a)
end
break
end

if a_x == cell_x then
while a ~= cell do
if level.solid[a] then
break
end

a = a - W
KlakCell(a)
end
end

if cell_x < a_x  then
a = a - W - 1
KlakCell(a)
end

if cell_x > a_x then
a = a - W + 1
KlakCell(a)
end

end

if cell > a then

if a_y == cell_y then
while a ~= cell do
if level.solid[a] then
break
end
a = a + 1
KlakCell(a-1)
end
break
end

if a_x == cell_x then
while a ~= cell do
if level.solid[a] then
break
end

a = a + W
KlakCell(a)
end
end 

if a_x > cell_x then
a = a + W - 1
KlakCell(a)
end

if a_x < cell_x then
a = a + W + 1
KlakCell(a)
end
end 
end
end

end,
    showQuestWindow = function(self, text)
        local wnd = luajava.newInstance(RPD.Objects.Ui.WndQuest, self, text)
        RPD.GameScene:show(wnd)
    end
}

return EPD