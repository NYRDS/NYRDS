--
-- User: mike
-- Date: 24.01.2018
-- Time: 23:58
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

return mob.init{
spawn = function(self)
RPD.permanentBuff(self, RPD.Buffs.Roots)
if not storage.get("RotHeartSpawn") then
storage.put("RotHeartSpawn",true)
for i = 0,RPD.Dungeon.level:getLength()-1 do   
    if RPD.Dungeon.level.map[i] == RPD.Terrain.EXIT then
RPD.Dungeon.level:set(i-1, RPD.Terrain.LOCKED_EXIT )
RPD.GameScene:updateMap(i-1)
    end
end

RPD.placeBlob(RPD.Blobs.Regrowth, self:getPos(), 100);
if self:getPos() > 32*10 and self:getPos() < 32*22 then
local level = RPD.Dungeon.level
local x = level:cellX(self:getPos())
local y = level:cellY(self:getPos())
 for i = x - 10, x + 10 do
  for j = y - 10, y + 10 do
local pos = level:cell(i,j)
local soul =  RPD.Actor:findChar(pos)
if soul and soul ~= self and soul ~= RPD.Dungeon.hero then
soul:destroy()
local mob = RPD.MobFactory:mobByName("RotLasher")
mob:setPos(RPD.Dungeon.level:randomRespawnCell())
level:spawnMob(mob);
end
end
end
elseif self:getPos() >32*5 and self:getPos() < 32*27 then
local level = RPD.Dungeon.level
local x = level:cellX(self:getPos())
local y = level:cellY(self:getPos())
 for i = x - 5, x + 5 do
  for j = y - 5, y + 5 do
local pos = level:cell(i,j)
local soul =  RPD.Actor:findChar(pos)
if soul and soul ~= self and soul ~= RPD.Dungeon.hero then
soul:destroy()
local mob = RPD.MobFactory:mobByName("RotLasher")
mob:setPos(RPD.Dungeon.level:randomRespawnCell())
level:spawnMob(mob);
end
end
end
end

end
end,
damage = function(self, level)
RPD.placeBlob(RPD.Blobs.ToxicGas, self:getPos(), 20);
end,
die = function(self)
for i = 0,RPD.Dungeon.level:getLength()-1 do
local mob = RPD.Actor:findChar(i)  
if mob ~= RPD.Dungeon.hero then
if mob and mob:getMobClassName() == "RotLasher" then
mob:damage(100,self)
end
end
end
end
}
