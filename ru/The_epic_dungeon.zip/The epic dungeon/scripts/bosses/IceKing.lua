--
-- User: mike
-- Date: 23.11.2017
-- Time: 21:04
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"

return mob.init({ 
    zapProc = function(self, enemy,dmg)
RPD.affectBuff(enemy, RPD.Buffs.Frost,4)
local mob = RPD.MobFactory:mobByName("IceGaurd") 
mob:setPos(48)
RPD.Dungeon.level:spawnMob(mob)
mob:setPos(56)
RPD.Dungeon.level:spawnMob(mob)
mob:setPos(153)
RPD.Dungeon.level:spawnMob(mob)
mob:setPos(161)
RPD.Dungeon.level:spawnMob(mob)
local level = RPD.Dungeon.level
local x = level:cellX(self:getPos())
local y = level:cellY(self:getPos())
        for i = x - 2, x + 2 do
         for j = y - 3, y + 3 do
local pos = level:cell(i,j)
if level.map[pos] == RPD.Terrain.EMPTY and pos ~= self:getPos() then
RPD.placePseudoBlob( RPD.PseudoBlobs.Freezing, pos)
RPD.zapEffect(self:getPos(), pos, "Ice")
end
end
end
return dmg
end,
    die = function(enemy, self, cell, dmg)
local level = RPD.Dungeon.level
local x = level:cellX(self:getPos())
local y = level:cellY(self:getPos())
RPD.GameScene:flash(0xFFFFFF)
        for i = x - 5, x + 5 do
         for j = y - 5, y + 5 do
local pos = level:cell(i,j)
RPD.Dungeon.level:set(pos, RPD.Terrain.EMPTY )
RPD.GameScene:updateMap(pos)
end
end
end

  })


