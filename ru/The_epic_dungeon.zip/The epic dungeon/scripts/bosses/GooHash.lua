--
-- User: mike
-- Date: 28.11.2017
-- Time: 22:20
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"

return mob.init({
    move = function(self, cell)
            local mob = RPD.MobFactory:mobByName("GooZombie")                mob:setPos(self:getPos())
            RPD.Dungeon.level:spawnMob(mob)
    end,
    zapProc = function(self, enemy, dmg) -- ranged attack
        RPD.affectBuff(enemy, RPD.Buffs.Slow , 10)
        return dmg
    end,
    die = function(enemy, self, cell, dmg)
RPD.GameScene:flash(0xFFFFFF)
        local level = RPD.Dungeon.level
local item = RPD.ItemFactory:itemByName("SkeletonKey")
level:drop(item,self:getPos())
end
})



