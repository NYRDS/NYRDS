--
-- User: mike
-- Date: 25.01.2018
-- Time: 0:26
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"


return mob.init{
    stats = function(self)
                RPD.permanentBuff(self, RPD.Buffs.Roots)
end,
    zapProc = function(self, enemy, dmg) -- ranged attack
        RPD.affectBuff(enemy, RPD.Buffs.Frost,4)
        return dmg
    end,
    spawn = function(self,level)
local level = RPD.Dungeon.level
local x = level:cellX(self:getPos())
local y = level:cellY(self:getPos())
        for i = x - 3, x + 3 do
         for j = y - 3, y + 3 do
local pos = level:cell(i,j)
level:set(pos, RPD.Terrain.BOOKSHELF )
RPD.GameScene:updateMap(pos)
end
end
        for i = x - 0, x + 0 do
         for j = y - 3, y + 3 do
local pos = level:cell(i,j)
level:set(pos, RPD.Terrain.DOOR )
RPD.GameScene:updateMap(pos)
end
end
        for i = x - 3, x + 3 do
         for j = y - 0, y + 0 do
local pos = level:cell(i,j)
level:set(pos, RPD.Terrain.DOOR )
RPD.GameScene:updateMap(pos)
end
end
        for i = x - 2, x + 2 do
         for j = y - 2, y + 2 do
local pos = level:cell(i,j)
level:set(pos, RPD.Terrain.EMPTY_DECO )
RPD.GameScene:updateMap(pos)
end
end
level:set(self:getPos(), RPD.Terrain.PEDESTAL )
RPD.GameScene:updateMap(self:getPos())
end
}
