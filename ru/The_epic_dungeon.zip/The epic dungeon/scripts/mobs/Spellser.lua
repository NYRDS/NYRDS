--
-- User: mike
-- Date: 25.01.2018
-- Time: 0:26
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"

 local mobs = {
 "AirElemental",
"WaterElemental",
"EarthElemental",
"Elemental",
"IceElemental",
"LightingElemental"
}
return mob.init{
    zapProc = function(self, cause) 
        local level = RPD.Dungeon.level
            local mob = RPD.MobFactory:mobByName(mobs[math.random(1,6)])
            local pos = level:getEmptyCellNextTo(self:getPos())
            if (level:cellValid(pos)) then
                mob:setPos(pos)
                level:spawnMob(mob)

            end
        end
}
