--
-- User: mike
-- Date: 25.01.2018
-- Time: 0:26
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"

return mob.init{
    damage = function(self, enemy, dmg) -- ranged attack
self:getSprite():emitter():pour( RPD.Sfx.ShadowParticle.UP, 0.8 )
end,
spawn = function(self, enemy, dmg) 
self:getSprite():emitter():pour( RPD.Sfx.FlameParticle.FACTORY, 0.1
)
end,
    zapProc = function(self, enemy, dmg) 
local levelSize = RPD.Dungeon.level:getLength()
        local cell = math.random(levelSize)-1
        if not RPD.Dungeon.level.solid[cell] then
            RPD.placeBlob( RPD.Blobs.Fire, cell, 10)
            RPD.placeBlob( RPD.Blobs.Fire, RPD.Dungeon.hero:getPos(), 10)
            RPD.zapEffect(self:getPos(), cell, "Fire")
        end
        return true
    end
}
