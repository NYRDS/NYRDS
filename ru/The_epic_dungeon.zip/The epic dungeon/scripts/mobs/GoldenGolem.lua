--
-- User: mike
-- Date: 23.11.2017
-- Time: 21:04
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"
        local level = RPD.Dungeon.level

return mob.init({
    damage = function(self)
        print(self, cause)
local item = RPD.ItemFactory:itemByName("Gold")
level:drop(item,self:getPos())
 end,
    die = function(self, cause)
       for i = 1,2 do
            local mob = RPD.MobFactory:mobByName("GoldenStatue")
            local pos = level:getEmptyCellNextTo(self:getPos())
            if (level:cellValid(pos)) then
                mob:setPos(pos)
                level:spawnMob(mob)
           end
        end
    end
})


