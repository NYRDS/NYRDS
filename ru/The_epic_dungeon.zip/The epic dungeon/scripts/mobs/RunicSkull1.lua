--
-- User: mike
-- Date: 25.01.2018
-- Time: 0:26
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"

return mob.init{
    zapProc = function(self, enemy, dmg)
local hero = RPD.Dungeon.hero
hero:hp(math.min(hero:hp()+10));
          if cloud == nil then
cloud = hero:getSprite():emitter()
cloud:burst(RPD.Sfx.Speck:factory(RPD.Sfx.Speck.HEALING ), 5)
    end 
  end 
}
