--
-- User: mike
-- Date: 06.11.2017
-- Time: 23:57
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local actor = require "scripts/lib/actor"

local Ginerator = require "scripts/lib/Ginerator"

local storage = require "scripts/lib/storage"

return actor.init({
    activate = function()
Ginerator.CreateNewWalls("Sewer/Wall","Sewer/Wall_Deco","Sewer/Wall_Sp","Sewer/Wall_Deco_Sp","Sewer/Door","Sewer/Door_Sp","Sewer/LockedDoor","Sewer/LockedDoor_Sp","Sewer/Barricade","Sewer/Barricade_Sp","Sewer/Water","Sewer/Bookshelf","Sewer/Bookshelf_empty","Sewer/Bookshelf_sp")
return true
end,
    actionTime = function()
        return 1
    end,
act = function()
return true
end
})