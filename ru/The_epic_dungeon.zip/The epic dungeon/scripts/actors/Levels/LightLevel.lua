--
-- User: mike
-- Date: 06.11.2017
-- Time: 23:57
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local actor = require "scripts/lib/actor"

local Ginerator = require "scripts/lib/Ginerator"

local storage = require "scripts/lib/storage"

return actor.init({
    activate = function()
if RPD.Dungeon.depth == 25 then
       local wnd = RPD.new(RPD.Objects.Ui.WndStory,"После дворфийской метрополии простирался ещё один подземный город. Никто не знает, кто здесь жил и почему он погиб. Некоторые полагают, что город погиб по той же причине, что и дворфийская метрополия: великая война со старым богом. Лишь немногие добирались так далеко...")
RPD.GameScene:show(wnd)
end
if RPD.Dungeon.depth == 27 then
local mob = RPD.MobFactory:mobByName("AzuterronNPC")
local RuneMaster = RPD.MobFactory:mobByName("RuneMasterNPC")
for i = 1,RPD.Dungeon.level:getLength()-1 do           
local maybeMob = RPD.Actor:findChar(i)          
if maybeMob and maybeMob ~= RPD.Dungeon.hero and maybeMob:getMobClassName() == "AzuterronNPC" then
maybeMob:destroy()
RuneMaster:setPos(i)
RPD.Dungeon.level:spawnMob(RuneMaster)
end
end
end
if RPD.Dungeon.depth == 30 then
RPD.Sfx.CellEmitter:get(249):pour(RPD.Sfx.ElmoParticle.FACTORY, 0.08);
RPD.Sfx.CellEmitter:get(247):pour(RPD.Sfx.ElmoParticle.FACTORY, 0.08);
RPD.Sfx.CellEmitter:get(217):pour(RPD.Sfx.ElmoParticle.FACTORY, 0.08);
RPD.Sfx.CellEmitter:get(215):pour(RPD.Sfx.ElmoParticle.FACTORY, 0.08)
end
return true
end,
    actionTime = function()
        return 1
    end,
act = function()
return true
end
})
