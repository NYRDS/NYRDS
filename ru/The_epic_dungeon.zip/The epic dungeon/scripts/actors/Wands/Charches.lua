--
-- User: mike
-- Date: 06.11.2017
-- Time: 23:57
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"
local actor = require "scripts/lib/actor"
local EPD = require "scripts/lib/dopClasses"
return actor.init({
    act = function()
if EPD.a < 4 then
EPD.a = EPD.a + 1
end
if EPD.b < 4 then
EPD.b = EPD.b + 1
end
if EPD.c < 6 then
EPD.c = EPD.c + 1
end
if EPD.d < 3 then
EPD.d = EPD.d +1
end
if EPD.i < 4 then
EPD.i = EPD.i +1
end
if EPD.f < 4 then
EPD.f = EPD.f + 1
end
if EPD.g < 3 then
EPD.g = EPD.g +1
end
if EPD.e < 3 then
EPD.e = EPD.e +1
end
if EPD.j < 3 then
EPD.j = EPD.j +1
end
if EPD.k < 3 then
EPD.k = EPD.k +1
end
if EPD.m < 2 then
EPD.m = EPD.m + 1
end

        return true
    end,
    actionTime = function()
        return 1
    end
})