--
-- User: mike
-- Date: 06.11.2017
-- Time: 23:57
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"
local actor = require "scripts/lib/actor"
local EPD = require "scripts/lib/dopClasses"
return actor.init({
    act = function()
if EPD.h < 1 then
EPD.h = EPD.h + 1
end
if EPD.l < 1 then
EPD.l = EPD.l +1
end
        return true
    end,
    actionTime = function()
        return 1
    end
})