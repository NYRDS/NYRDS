--
-- User: mike
-- Date: 06.11.2017
-- Time: 23:57
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"
local actor = require "scripts/lib/actor"

return actor.init({
    actionTime = function()
        return math.huge
    end,
    activate = function()
       local wnd = RPD.new(RPD.Objects.Ui.WndStory,"Адская крепость, пролигающая после изумрудного собора является тоже своеобразной задворкой. Никому не известно кто построил её. Историки утверждают, что она была создана той неизвестной рассой и использовалось как укрытие, другие же суйверные говорят, что её построил сам дьявол, чтобы пытать там грешные души...")
       RPD.GameScene:show(wnd)
local mob = RPD.MobFactory:mobByName("Shopkeeper")
local CastleKeeper = RPD.MobFactory:mobByName("CastleKeeperNPC")
for i = 1,RPD.Dungeon.level:getLength()-1 do           
local maybeMob = RPD.Actor:findChar(i)          
if maybeMob and maybeMob ~= RPD.Dungeon.hero and maybeMob:getMobClassName() == "Shopkeeper" then
maybeMob:destroy()
CastleKeeper:setPos(i)
RPD.Dungeon.level:spawnMob(CastleKeeper)
end
end

    end
})