--
-- User: mike
-- Date: 06.11.2017
-- Time: 23:57
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"
local actor = require "scripts/lib/actor"

return actor.init({
    actionTime = function()
        return math.huge
    end,
    activate = function()
       local wnd = RPD.new(RPD.Objects.Ui.WndStory,"Адская крепость, пролигающая после изумрудного собора является тоже своеобразной задворкой. Никому не известно кто построил её. Историки утверждают, что она была создана той неизвестной рассой и использовалось как укрытие, другие же суйверные говорят, что её построил сам дьявол, чтобы пытать там грешные души...")
       RPD.GameScene:show(wnd)
    end
})