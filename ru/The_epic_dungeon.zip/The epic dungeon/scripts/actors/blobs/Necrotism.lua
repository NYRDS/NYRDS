act = function(hero, cell, level)
        local level = RPD.Dungeon.level
        local hero = RPD.Dungeon.hero
        local x = level:cellX(cell)
        local y = level:cellY(cell)
        for i = x - 3, x + 3 do
            for j = y - 3, y + 3 do
            local pos = level:cell(i,j)
 
            if (level:cellValid(pos)) then
 
RPD.Sfx.CellEmitter:get(pos):start(RPD.Sfx.PurpleParticle.FACTORY, 0.02, 200)
 local soul =  RPD.Actor:findChar(cell)
 end
                if soul then
RPD.affectBuff(soul, RPD.Buffs.Charm , 10);
RPD.affectBuff(soul, RPD.Buffs.Poison , 10);
soul:getSprite():emitter():start(RPD.Sfx.PurpleParticle.FACTORY, 0.02, 200)
              end
        end
    end 
end