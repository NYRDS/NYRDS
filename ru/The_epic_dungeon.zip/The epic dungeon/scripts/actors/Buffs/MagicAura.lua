--
-- User: mike
-- Date: 06.11.2017
-- Time: 23:57
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"
local actor = require "scripts/lib/actor"
return actor.init({
   act = function()
    
        local hero = RPD.Dungeon.hero
        RPD.Buffs.Buff:affect(hero, RPD.Buffs.Blessed, 1 );
    RPD.Sfx.CellEmitter:get(hero:getPos()):start(RPD.Sfx.ElmoParticle.FACTORY, 0.08)
   return true
    end,
    actionTime = function()
        return 1
    end
})