--
-- User: mike
-- Date: 25.11.2017
-- Time: 22:56
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"

local quest = require"scripts/lib/quest"

local questName = "Demo Quest"

local items = {
 "RunicSkull1",
 "RunicSkull2",
 "RunicSkull3",
 "RunicSkull4"
}
return mob.init({
    interact = function(self, chr)
        if not quest.isGiven(questName) then
            self:say("Привет приключенец! Убей 10 тёмных рыцарей и возврощайся сюда.")
            quest.give(questName, chr, {kills={"DeathKnight"}})
            return
        end

        if quest.isCompleted(questName) then
            self:say("Спасибо!")
            return
        end

        local ratsKilled = quest.state(questName).kills.DeathKnight or 0

        if ratsKilled == 0 then
            return
        end

        if ratsKilled < 10 then
            self:say("Ещё не всё.")
        else
            self:say("Хорошая работа! Вот возьми.")
            RPD.Dungeon.level:drop(RPD.ItemFactory:itemByName(items[math.random(1,4)]),chr:getPos())
            quest.complete(questName)
        end
    end
})
