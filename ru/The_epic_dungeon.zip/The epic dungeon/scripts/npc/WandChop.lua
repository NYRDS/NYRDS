--[[
    Created by Богдашка Ивашка.
    DateTime: 19.01.19 21:24
    This file is part of pixel-dungeon-remix
]]

local RPD = require "scripts/lib/commonClasses"

local mob = require"scripts/lib/mob"

local BattleWand = 
{
"WandOfLightning",
"WandOfFirebolt",
"WandOfMagicMissile",
"WandOfDisintegration",
"WandOfAvalanche",
 "WandOfFlock",
"WandOfIcebolt",
"WandOfShadowbolt"
}

local NoBattleWand =
{
 "WandOfRegrowth",
"WandOfPoison",
"WandOfAmok",
 "WandOfSlowness",
"WandOfBlink",
"WandOfTelekinesis",
"WandOfTeleportation"
} 
local npc
local client

local dialog = function(index)
    if index == 0 then
        if client:gold() >= 50 then
            client:spendGold(50)
RPD.Dungeon.level:drop( RPD.ItemFactory:itemByName(NoBattleWand[math.random(1,7)]), client:getPos())
            return
        end
        npc:say("Прости, но ниже цену вообще никак.")
    end

    if index == 1 then
        if client:gold() >= 100 then
            client:spendGold(100)
   RPD.Dungeon.level:drop( RPD.ItemFactory:itemByName(BattleWand[math.random(1,7)]), client:getPos())
            return
        end
        npc:say("Прости, но ниже цену вообще никак.")
    end

    if index == 2 then
        if client:gold() >= 200 then
            client:spendGold(200)      
     RPD.Dungeon.level:drop( RPD.ItemFactory:itemByName("ScrollOfRecharging"), client:getPos())
            return
        end
        npc:say("Прости, но ниже цену вообще никак.")
    end
 end

return mob.init({
    interact = function(self, chr)
        client = chr
        npc = self

        RPD.chooseOption( dialog,
                "Торговец волшебными палочками",
                "У меня самые лучшие волшебные палочки! Просто мамой клянусь!",
                "Не боевая палочка -50g",
                "Боевая палочка -100g",
                "Перезарядка -200g",
                "Уйти"
        )
    end
})
