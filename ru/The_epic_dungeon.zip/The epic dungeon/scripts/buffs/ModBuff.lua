-- This is demo buff for charAct

local RPD  = require "scripts/lib/commonClasses"

local buff = require "scripts/lib/buff"

local EPD = require "scripts/lib/dopClasses"

local storage = require "scripts/lib/storage"

return buff.init{
    desc  = function ()
        return {
            icon          = -1,
            name          = "CounterBuff_Name",
            info          = "CounterBuff_Info",
        }
    end,
    attachTo = function(self, buff, target)
cry = nil
    if type(target) == nil or type(RPD.Dungeon.hero) == nil then
    return
    end
    return false
    end,
    act = function(self,buff)
        buff:detach()
    end,



    detach = function(self, buff)
    end,
    act = function(self,buff)
        buff:detach()
end, 

    charAct = function(self,buff)
--[[
if not storage.get("miniBoss1") then
if RPD.Dungeon.depth == 4 then
storage.put("miniBoss1",true)
local level = RPD.Dungeon.level
local mob = RPD.MobFactory:mobByName("miniBosses/AngryRat")
mob:setPos(RPD.Dungeon.level:randomRespawnCell())
level:spawnMob(mob);
end
end
--]]

if not storage.get("miniBoss3") then
if RPD.Dungeon.depth == 9 then
storage.put("miniBoss3",true)
local level = RPD.Dungeon.level
local mob = RPD.MobFactory:mobByName("miniBosses/RotHeart")
mob:setPos(RPD.Dungeon.level:randomRespawnCell())
level:spawnMob(mob);
end
end

if not storage.get("miniBoss4") then
if RPD.Dungeon.depth == 13 then
storage.put("miniBoss4",true)
local level = RPD.Dungeon.level
local mob = RPD.MobFactory:mobByName("miniBosses/Spellser")
mob:setPos(RPD.Dungeon.level:randomRespawnCell())
level:spawnMob(mob);
end
end

if not storage.get("Crystal") then
local Crystal = RPD.MobFactory:mobByName("Crystal")
local CrystalMod = RPD.MobFactory:mobByName("CrystalMod")
storage.put("Crystal",true)
for i = 1,RPD.Dungeon.level:getLength()-1 do  
local maybeMob = RPD.Actor:findChar(i)         
if maybeMob and maybeMob  ~= RPD.Dungeon.hero and maybeMob:getMobClassName() == "Crystal" then
maybeMob:destroy() 
maybeMob:getSprite():killAndErase()
CrystalMod:setPos(i)
RPD.Dungeon.level:spawnMob(CrystalMod)
end
end
end

EPD.time = EPD.time + 1
if EPD.time % 16 == 0 then
--RPD.glog("Перезарядка!")
if EPD.a < 4 then
EPD.a = EPD.a + 1
end
if EPD.b < 4 then
EPD.b = EPD.b + 1
end
if EPD.c < 6 then
EPD.c = EPD.c + 1
end
if EPD.d < 3 then
EPD.d = EPD.d +1
end
if EPD.i < 4 then
EPD.i = EPD.i +1
end
if EPD.f < 4 then
EPD.f = EPD.f + 1
end
if EPD.g < 3 then
EPD.g = EPD.g +1
end
if EPD.e < 3 then
EPD.e = EPD.e +1
end
if EPD.j < 3 then
EPD.j = EPD.j +1
end
if EPD.k < 3 then
EPD.k = EPD.k +1
end
end
if EPD.time % 42 == 0 then
--RPD.glog("Перезарядкаtttt!")
if EPD.h < 1 then
EPD.h = EPD.h + 1
end
if EPD.l < 1 then
EPD.l = EPD.l +1
end
if EPD.m < 2 then
EPD.m = EPD.m + 1
end
end
    end
}
