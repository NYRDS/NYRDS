-- This is demo buff for charAct

local RPD  = require "scripts/lib/commonClasses"

local buff = require "scripts/lib/buff"

return buff.init{
    desc  = function ()
        return {
            icon          = -1,
            name          = "CounterBuff_Name",
            info          = "CounterBuff_Info",
        }
    end,

    attachTo = function(self, buff, target)
pos = target:getPos()
        return true
    end,

    charAct = function(self,buff)
if RPD.Dungeon.hero:getSkillPoints() > 1 then
if RPD.Dungeon.hero:getNearestEnemy() then
RPD.Dungeon.hero:spendSkillPoints(1)
--if RPD.Dungeon.hero:canAttack(RPD.Dungeon.hero:getNearestEnemy()) then
RPD.Sfx.MagicMissile:whiteLight(RPD.Dungeon.hero:getSprite():getParent(),RPD.Dungeon.hero:getPos(),RPD.Dungeon.hero:getNearestEnemy():getPos(),nil)
RPD.Dungeon.hero:spend(RPD.Dungeon.hero:speed())
RPD.Dungeon.hero:attack(RPD.Dungeon.hero:getNearestEnemy())
RPD.Dungeon.hero:attackProc(RPD.Dungeon.hero:getNearestEnemy())
RPD.Dungeon.hero:getSprite():zap(RPD.Dungeon.hero:getNearestEnemy():getPos())
--end
end
end
end,
attackProc = function(self,buff,enemy,damage)
return math.random(2,5)
end,
getAttackAnimationClass = function()
return "bow"
end
}