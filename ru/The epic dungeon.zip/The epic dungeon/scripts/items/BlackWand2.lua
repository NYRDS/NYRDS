--
-- User: mike
-- Date: 29.01.2019
-- Time: 20:33
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"

        local hero = RPD.Dungeon.hero

return item.init{
    desc  = function ()
        return {
            image         = 22,
            imageFile     = "items/wands_remastered.png",
            name          = "Жезл некромантии",
            info          = "В этом маленьком на вид жезле находится могущественное заклятье некромантии. Оно очень быстро растворяется в воздухе, но если его подхватить, то жертва будет умирать очень долго и мучительно.",
            stackable     = false,
            defaultAction = "Wand_ACZap",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.zap} end,

    cellSelected = function(self, thisItem, action, cell)
        if action == RPD.Actions.zap then 
 RPD.zapEffect(hero:getPos(),cell, "Shadow")
 local level = RPD.Dungeon.level
        local x = level:cellX(cell)
        local y = level:cellY(cell)
        for i = x - 1, x + 1 do
            for j = y - 1, y + 1 do
            local pos = level:cell(i,j)
 local soul =  RPD.Actor:findChar(pos)
            if soul then 
 
RPD.Sfx.CellEmitter:get(pos):start(RPD.Sfx.PurpleParticle.FACTORY, 0.02, 20)
 RPD.affectBuff(soul, RPD.Buffs.Slow , 10000);
RPD.affectBuff(soul, RPD.Buffs.Poison , 10000);
RPD.affectBuff(soul, RPD.Buffs.Vertigo , 10000);
soul:getSprite():emitter():pour(RPD.Sfx.PurpleParticle.FACTORY, 0.02)
else
RPD.Sfx.CellEmitter:get(pos):start(RPD.Sfx.PurpleParticle.FACTORY, 0.02, 20)
              end
        end
    end 
end
end,
    execute = function(self, item, hero, action)
        if action == RPD.Actions.zap then
            item:selectCell( RPD.Actions.zap ,"Выбирете клетку")
        end
end
}
