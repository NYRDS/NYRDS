--
-- User: mike
-- Date: 26.05.2018
-- Time: 21:32
-- This file is part of Remixed Pixel Dungeon.
--

local RPD = require "scripts/lib/commonClasses"

local item = require "scripts/lib/item"


return item.init{
    desc  = function ()
        return {
           image     = 2,
            imageFile = "items/BooksInCityLibrary.png",
            name          = "Свиток стихий",
            info          = "При использовании этот свиток создаст случайного элементаля рядом с героем.",
            stackable     = true,
            defaultAction = "Scroll_ACRead",
            price         = 50
        }
    end,
    actions = function() return {RPD.Actions.read} end,
    execute = function(self, item, hero, action, cause )
        if action == RPD.Actions.read then
 local hero = RPD.Dungeon.hero
RPD.affectBuff(hero, RPD.Buffs.GasesImmunity , 10000);
 RPD.affectBuff(hero, RPD.Buffs.Light , 10000);
 RPD.affectBuff(hero, RPD.Buffs.Blessed , 10000);
 RPD.item("ScrollOfRemoveCurse"):uncurse(hero:getBelongings())
 end
 end
}