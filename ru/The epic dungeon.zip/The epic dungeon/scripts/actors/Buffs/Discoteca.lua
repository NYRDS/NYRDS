--[[
    Created by mike.
    DateTime: 25.10.18 22:21
    This file is part of pixel-dungeon-remix
]]



local RPD = require "scripts/lib/commonClasses"
local actor = require "scripts/lib/actor"

return actor.init({
    act = function()
        local levelSize = RPD.Dungeon.level:getLength()
        local cell = math.random(levelSize)-1
        local cell2 = math.random(levelSize)-1
        if not RPD.Dungeon.level.solid[cell] then
 RPD.zapEffect(cell2, cell, "DeathRay")
 
        end
        return true
    end,
    actionTime = function()
        return 1
    end
})